import React, { useRef, useEffect } from 'react';
import { WebsiteSettings } from '../App';

interface AboutUsProps {
  settings: WebsiteSettings;
  title: string;
  text: string;
  imageSeed: string;
}

const AboutUs: React.FC<AboutUsProps> = ({ settings, title, text, imageSeed }) => {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
        (entries) => {
            const [entry] = entries;
            entry.target.classList.toggle('is-visible', entry.isIntersecting);
        },
        { threshold: 0.1 }
    );

    const currentRef = sectionRef.current;
    if (currentRef) {
        observer.observe(currentRef);
    }

    return () => {
        if (currentRef) {
            observer.unobserve(currentRef);
        }
    };
  }, []);

  return (
    <section 
      id="about" 
      ref={sectionRef}
      className={`py-20 sm:py-24 bg-white ${settings.animations.enabled ? 'scroll-animate' : ''}`}
    >
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="order-2 md:order-1">
            <h2 className="text-3xl sm:text-4xl font-extrabold text-primary">{title}</h2>
            <div className="mt-6 text-lg text-text-muted space-y-4">
                {text.split('\n').map((paragraph, index) => (
                    <p key={index}>{paragraph}</p>
                ))}
            </div>
          </div>
          <div className="order-1 md:order-2">
            <div className="rounded-xl shadow-lg overflow-hidden border-4 border-white transform md:rotate-3 transition-transform duration-500 hover:rotate-0 hover:scale-105">
                 <img src={`https://picsum.photos/seed/${imageSeed}/800/600`} alt="Digital Catalyst Team" className="w-full h-auto object-cover" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutUs;