import React, { useState } from 'react';
import { Review, WebsiteSettings } from '../App';

interface StarRatingProps {
  rating: number;
  setRating?: (rating: number) => void;
  interactive?: boolean;
}

const Star: React.FC<{ filled: boolean; onClick?: () => void, isInteractive: boolean }> = ({ filled, onClick, isInteractive }) => (
    <svg 
        onClick={onClick}
        className={`transition-all duration-200 ${isInteractive ? 'w-8 h-8 cursor-pointer transform hover:scale-125' : 'w-6 h-6'}`}
        viewBox="0 0 24 24" 
        xmlns="http://www.w3.org/2000/svg"
    >
        <path 
            d="M12 .587l3.668 7.568 8.332 1.151-6.064 5.828 1.48 8.279-7.416-3.967-7.417 3.967 1.481-8.279-6.064-5.828 8.332-1.151z"
            fill={filled ? "url(#star-gradient)" : "#E5E7EB"}
            stroke={filled ? "#F59E0B" : "#D1D5DB"}
            strokeWidth="0.5"
        />
    </svg>
);


const StarRating: React.FC<StarRatingProps> = ({ rating, setRating, interactive = false }) => {
    const [hoverRating, setHoverRating] = useState(0);

    return (
        <div 
            className="flex items-center"
            onMouseLeave={interactive ? () => setHoverRating(0) : undefined}
        >
             {/* Gradient definition needed for SVG fill */}
            <svg width="0" height="0" className="absolute">
                <defs>
                    <linearGradient id="star-gradient" x1="0%" y1="0%" x2="0%" y2="100%">
                        <stop offset="0%" stopColor="#FBBF24" /> {/* amber-400 */}
                        <stop offset="100%" stopColor="#F59E0B" /> {/* amber-500 */}
                    </linearGradient>
                </defs>
            </svg>
            {[1, 2, 3, 4, 5].map((star) => (
                <div 
                    key={star} 
                    onMouseEnter={interactive ? () => setHoverRating(star) : undefined}
                >
                    <Star 
                        filled={star <= (hoverRating || rating)} 
                        onClick={interactive && setRating ? () => setRating(star) : undefined}
                        isInteractive={interactive}
                    />
                </div>
            ))}
        </div>
    );
};

interface RatingsAndReviewsProps {
  settings: WebsiteSettings;
  productTitle: string;
  prompt?: string;
  reviews: Review[];
  onAddReview: (reviewData: { rating: number; comment: string }) => void;
}

const RatingsAndReviews: React.FC<RatingsAndReviewsProps> = ({ settings, productTitle, prompt, reviews, onAddReview }) => {
  const [newRating, setNewRating] = useState(5);
  const [newComment, setNewComment] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newComment.trim() === '') return;
    onAddReview({ rating: newRating, comment: newComment });
    setSubmitted(true);
    setTimeout(() => {
        setNewComment('');
        setNewRating(5);
        setSubmitted(false);
    }, 3000);
  };
  
  const averageRating = reviews.length > 0
    ? reviews.reduce((acc, review) => acc + review.rating, 0) / reviews.length
    : 0;

  return (
    <div className="container mx-auto px-6">
      <div className="max-w-3xl mx-auto">
        <h2 className="text-3xl font-extrabold text-primary text-center">
          Customer Reviews for {productTitle}
        </h2>

        <div className="mt-4 flex flex-col items-center justify-center gap-2">
            <StarRating rating={averageRating} />
            <p className="text-text-muted">
                {reviews.length > 0 
                    ? `${averageRating.toFixed(1)} out of 5 stars (${reviews.length} ratings)`
                    : 'No reviews yet. Be the first!'
                }
            </p>
        </div>

        <div className="mt-12 bg-white p-8 rounded-xl shadow-lg border">
          <h3 className="text-xl font-bold text-primary text-center">
            {prompt || 'Leave a Review'}
          </h3>
          {submitted ? (
            <p className="mt-4 text-center text-green-600 font-semibold animate-fade-in">Thank you for your feedback!</p>
          ) : (
            <form onSubmit={handleSubmit} className="mt-6">
              <div className="flex flex-col items-center">
                <label className="font-semibold text-text">Your Rating</label>
                <div className="mt-2">
                  <StarRating rating={newRating} setRating={setNewRating} interactive={true} />
                </div>
              </div>
              <div className="mt-6">
                <label htmlFor="comment" className="block font-semibold text-text mb-2">Your Review</label>
                <textarea
                  id="comment"
                  rows={4}
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent transition-all"
                  placeholder={`What did you think of the ${productTitle}?`}
                  required
                ></textarea>
              </div>
              <div className="mt-6 text-center">
                <button type="submit" className="bg-primary text-white font-bold px-8 py-3 rounded-lg hover:opacity-90 transition-all duration-300 transform active:scale-95">
                  Submit Review
                </button>
              </div>
            </form>
          )}
        </div>

        <div className="mt-12 space-y-8">
          {reviews.map((review, index) => (
            <div key={index} className="bg-white p-6 rounded-lg shadow-md border animate-fade-in-up" style={{ animationDelay: `${index * 100}ms`}}>
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-primary">{review.name}</h4>
                <span className="text-sm text-text-muted">{review.date}</span>
              </div>
              <div className="mt-2">
                <StarRating rating={review.rating} />
              </div>
              <p className="mt-4 text-text-muted">{review.comment}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default RatingsAndReviews;