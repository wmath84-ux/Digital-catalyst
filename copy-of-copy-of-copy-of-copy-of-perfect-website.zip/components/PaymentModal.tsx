import React from 'react';
import { WebsiteSettings, ProductWithRating, CartItem } from '../App';

interface PaymentModalProps {
  settings: WebsiteSettings;
  originalPrice: number;
  salePrice?: number | null; // Only for single item
  couponDiscount: number;
  finalPrice: number;
  onClose: () => void;
  onConfirm: () => void;
  productTitle?: string; // For single item
  cartItems?: ({ product: ProductWithRating } & CartItem)[]; // For cart checkout
}

const PaymentModal: React.FC<PaymentModalProps> = ({ 
    settings, productTitle, originalPrice, salePrice, couponDiscount, finalPrice, onClose, onConfirm, cartItems 
}) => {
  const googleFormUrl = "https://docs.google.com/forms/d/e/1FAIpQLSd2g7vW2GjoErahl-ds2geHu-FDIIFleDhasj65Cgu2l3pPrg/viewform?usp=sharing&ouid=116619415883411825251";
  const razorpayUrl = "https://pages.razorpay.com/pl_RIfTCxnYj73xqE/view"; 
  const isCartMode = !!cartItems && cartItems.length > 0;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex justify-center items-center p-4 animate-fade-in" aria-labelledby="modal-title" role="dialog" aria-modal="true">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg p-8 relative transform transition-all animate-scale-in-up">
        <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600" aria-label="Close modal">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
        </button>

        <h2 id="modal-title" className="text-2xl font-bold text-primary text-center">Complete Your Purchase</h2>
        {!isCartMode && <p className="text-center text-text-muted mt-2">You're purchasing: <span className="font-semibold">{productTitle}</span></p>}
        
        <div className="bg-gray-50 p-4 rounded-lg border mt-6">
            <h3 className="font-semibold text-lg text-gray-800 mb-3">Order Summary</h3>
            
            {isCartMode && (
                <div className="max-h-32 overflow-y-auto pr-2 mb-3 border-b pb-2">
                    {cartItems.map(item => (
                        <div key={item.productId} className="flex justify-between items-center text-xs py-1">
                           <span className="text-gray-600 truncate pr-2">{item.product.title} (x{item.quantity})</span>
                           <span className="text-gray-800 font-medium">₹{(parseFloat((item.product.salePrice || item.product.price).replace('₹', '')) * item.quantity).toFixed(2)}</span>
                        </div>
                    ))}
                </div>
            )}
            
            <div className="space-y-2 text-sm">
                <div className="flex justify-between text-text-muted">
                    <span>{isCartMode ? 'Subtotal:' : 'Original Price:'}</span>
                    <span className={!isCartMode && salePrice !== null ? 'line-through' : ''}>₹{originalPrice.toFixed(2)}</span>
                </div>
                {!isCartMode && salePrice !== null && (
                    <div className="flex justify-between text-gray-800 font-semibold">
                        <span>Sale Price:</span>
                        <span>₹{salePrice.toFixed(2)}</span>
                    </div>
                )}
                {couponDiscount > 0 && (
                    <div className="flex justify-between text-green-600 font-semibold">
                        <span>Coupon Discount:</span>
                        <span>- ₹{couponDiscount.toFixed(2)}</span>
                    </div>
                )}
                <div className="border-t my-2"></div>
                <div className="flex justify-between font-bold text-base text-gray-900">
                    <span>Total Amount:</span>
                    <span>₹{finalPrice.toFixed(2)}</span>
                </div>
            </div>
        </div>

        <div className="mt-8 space-y-6">
          <div>
            <div className="flex items-center">
              <div className="bg-primary text-white rounded-full h-8 w-8 flex-shrink-0 flex items-center justify-center font-bold text-lg">1</div>
              <h3 className="ml-4 text-xl font-semibold text-primary">Make Payment</h3>
            </div>
            <div className="pl-12">
              <p className="mt-2 text-text-muted">
                Click the button below to pay. After paying, please copy the <strong>Payment ID</strong> and take a <strong>screenshot</strong>. You'll need it for Step 2.
              </p>
              <div className="mt-4">
                <a href={razorpayUrl} target="_blank" rel="noopener noreferrer" className="inline-block w-full text-center bg-primary text-white font-semibold px-6 py-3 rounded-lg hover:opacity-90 transition-all duration-300 transform active:scale-95">
                  Pay Now via Razorpay
                </a>
              </div>
            </div>
          </div>

          <div>
            <div className="flex items-center">
              <div className="bg-primary text-white rounded-full h-8 w-8 flex-shrink-0 flex items-center justify-center font-bold text-lg">2</div>
              <h3 className="ml-4 text-xl font-semibold text-primary">Confirm Your Purchase</h3>
            </div>
            <div className="pl-12">
              <p className="mt-2 text-text-muted">
                Submit your payment details in our Google Form to get instant access to your product.
              </p>
              <div className="mt-4">
                <a href={googleFormUrl} target="_blank" rel="noopener noreferrer" className="inline-block w-full text-center bg-transparent border-2 border-primary text-primary font-semibold px-6 py-3 rounded-lg hover:bg-primary/10 transition-all duration-300 transform active:scale-95">
                  Fill Confirmation Form
                </a>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8 border-t pt-6">
          <p className="text-center text-sm text-text-muted mb-4">Once you have completed both steps, click below to proceed.</p>
          <button 
            onClick={onConfirm}
            className="w-full bg-green-500 text-white font-bold px-8 py-3 rounded-lg hover:bg-green-600 transition-all duration-300 transform hover:scale-105 active:scale-100"
          >
            I've Paid & Submitted The Form!
          </button>
        </div>
      </div>
    </div>
  );
};

export default PaymentModal;