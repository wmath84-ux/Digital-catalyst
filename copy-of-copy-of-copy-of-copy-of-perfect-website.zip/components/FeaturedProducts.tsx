
import React, { useState, useEffect, useRef } from 'react';
import { ProductWithRating, WebsiteSettings, Coupon } from '../App';
import ProductCard from './ProductCard';

interface FeaturedProductsProps {
  settings: WebsiteSettings;
  title: string;
  products: ProductWithRating[];
  onViewProduct: (product: ProductWithRating, sectionId?: string) => void;
  wishlist: number[];
  onToggleWishlist: (id: number) => void;
  onAddToCart: (productId: number, quantity?: number) => void;
  onQuickView: (product: ProductWithRating) => void;
  bgColor?: string;
  coupons: Coupon[];
}

const FeaturedProducts: React.FC<FeaturedProductsProps> = ({ settings, title, products, onViewProduct, wishlist, onToggleWishlist, onAddToCart, onQuickView, bgColor = 'bg-background', coupons }) => {
  const sectionRef = useRef<HTMLElement>(null);
  const gridRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
        (entries) => {
            const [entry] = entries;
            if (entry.target) {
              entry.target.classList.toggle('is-visible', entry.isIntersecting);
            }
        },
        { threshold: 0.05 }
    );

    const currentRef = sectionRef.current;
    if (currentRef) {
        observer.observe(currentRef);
    }

    const gridObserver = new IntersectionObserver(
        (entries) => {
            const [entry] = entries;
            if (entry.target) {
                entry.target.classList.toggle('is-visible', entry.isIntersecting);
            }
        },
        { threshold: 0.05 }
    );
    const currentGridRef = gridRef.current;
    if(currentGridRef) gridObserver.observe(currentGridRef);


    return () => {
        if (currentRef) observer.unobserve(currentRef);
        if (currentGridRef) gridObserver.unobserve(currentGridRef);
    };
  }, []);
  
  if (!products || products.length === 0) return null;

  return (
    <section 
      ref={sectionRef}
      className={`py-20 sm:py-24 ${bgColor} ${settings.animations.enabled ? 'scroll-animate' : ''}`}
    >
      <div className="container mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto">
          <h2 className="text-3xl sm:text-4xl font-extrabold text-primary">{title}</h2>
        </div>
        <div ref={gridRef} className={`mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12 ${settings.animations.enabled ? 'stagger-animate-container' : ''}`}>
          {products.map((product, index) => (
            <ProductCard 
              key={product.id} 
              settings={settings}
              product={product} 
              onViewDetails={(sectionId) => onViewProduct(product, sectionId)}
              isWishlisted={wishlist.includes(product.id)}
              onToggleWishlist={onToggleWishlist}
              onAddToCart={onAddToCart}
              onQuickView={onQuickView}
              animationDelay={index}
              coupons={coupons}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturedProducts;
