import React, { useRef, useEffect } from 'react';
import { WebsiteSettings } from '../App';

interface HeroProps {
  settings: WebsiteSettings;
  onNavigateToPolicies: () => void;
  onNavigateToAllProducts: () => void;
  onOpenBlogModal: () => void;
  onOpenFreeModal: () => void;
  onOpenAnnouncementsModal: () => void;
}

const Hero: React.FC<HeroProps> = ({ settings, onNavigateToPolicies, onNavigateToAllProducts, onOpenBlogModal, onOpenFreeModal, onOpenAnnouncementsModal }) => {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
        (entries) => {
            const [entry] = entries;
            entry.target.classList.toggle('is-visible', entry.isIntersecting);
        },
        { threshold: 0.05 }
    );

    const currentRef = sectionRef.current;
    if (currentRef) {
        observer.observe(currentRef);
    }

    return () => {
        if (currentRef) {
            observer.unobserve(currentRef);
        }
    };
  }, []);

  return (
    <section ref={sectionRef} className="relative bg-primary text-white overflow-hidden stagger-animate-container">
      <div className="absolute inset-0 -z-10 animate-gradient-flow bg-[length:400%_400%]" style={{
          background: `linear-gradient(-45deg, ${settings.theme.primaryColor}, ${settings.theme.accentColor}, #2563eb, #9333ea)`
      }}></div>
      <div className="container mx-auto px-6 text-center py-20 sm:py-24 lg:py-32 relative z-10">
        <div className="max-w-4xl mx-auto bg-black/20 backdrop-blur-xl rounded-2xl p-8 sm:p-12 border border-white/20">
          <h1 
            className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight animate-child animate-delay-1"
            style={{ textShadow: '0 2px 10px rgba(0,0,0,0.3)' }}
          >
            {settings.content.heroTitle}
          </h1>
          <p 
            className="mt-6 text-lg lg:text-xl text-indigo-100 animate-child animate-delay-2"
          >
            {settings.content.heroSubtitle}
          </p>
          <div 
            className="mt-10 flex flex-col sm:flex-row justify-center items-center gap-4 animate-child animate-delay-3"
          >
            <button onClick={onNavigateToAllProducts} className="w-full sm:w-auto bg-white text-primary font-semibold px-8 py-3 rounded-lg hover:bg-gray-200 transition-all duration-300 transform hover:scale-105 active:scale-100 shadow-lg">
              Explore Products
            </button>
            <button onClick={onNavigateToPolicies} className="w-full sm:w-auto bg-transparent border-2 border-white text-white font-semibold px-8 py-3 rounded-lg hover:bg-white/10 transition-colors duration-300 transform active:scale-95">
              View Our Policies
            </button>
          </div>
        </div>
        <div 
            className="mt-16 max-w-5xl mx-auto animate-child animate-delay-4"
        >
            <div className="bg-white rounded-xl shadow-2xl overflow-hidden border-4 border-white/20">
                <div className="h-10 bg-gray-100 flex items-center px-4 space-x-2">
                    <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                    <div className="w-3 h-3 bg-yellow-400 rounded-full"></div>
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                </div>
                <img src="https://picsum.photos/seed/online-business-success/1200/600" alt="Digital Marketing and E-commerce dashboard" className="w-full h-auto object-cover" />
            </div>
        </div>
         <div className="relative -mt-12 z-20 max-w-4xl mx-auto animate-child animate-delay-5">
            <div className="bg-white/10 backdrop-blur-lg border border-white/20 rounded-xl p-4 sm:p-6 flex flex-wrap items-center justify-center gap-3 sm:gap-6">
                 <button onClick={onOpenBlogModal} className="px-5 py-2 text-sm font-semibold rounded-full transition-all duration-300 bg-white/80 text-primary hover:bg-white shadow-sm transform active:scale-95">
                    Blog
                 </button>
                 <button onClick={onOpenFreeModal} className="px-5 py-2 text-sm font-semibold rounded-full transition-all duration-300 bg-white/20 text-white hover:bg-white/30 transform active:scale-95">
                    Free
                 </button>
                 <button onClick={onOpenAnnouncementsModal} className="px-5 py-2 text-sm font-semibold rounded-full transition-all duration-300 bg-white/20 text-white hover:bg-white/30 transform active:scale-95">
                    Announcement
                 </button>
            </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;