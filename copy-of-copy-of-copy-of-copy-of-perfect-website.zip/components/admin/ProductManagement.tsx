



















import React, { useState, useRef, useEffect, useLayoutEffect } from 'react';
import { Product, ProductWithRating, ProductFile, CourseModule, ProductFileType, Coupon, User } from '../../App';
import NewProductEmailPreviewModal from './NewProductEmailPreviewModal';

// FIREBASE IMPORTS for File Upload
import { storage } from '../../firebase';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';


// --- Helper Functions for Immutable Tree Updates ---

const recursiveUpdate = (
    modules: CourseModule[], 
    parentId: string | null, 
    updateCallback: (modules: CourseModule[]) => CourseModule[]
): CourseModule[] => {
    if (!modules) return []; // Safety check for undefined modules
    
    if (parentId === null) {
        return updateCallback(modules);
    }
    return modules.map(module => {
        if (module.id === parentId) {
            const currentModules = Array.isArray(module.modules) ? module.modules : [];
            return { ...module, modules: updateCallback(currentModules) };
        }
        if (module.modules && module.modules.length > 0) {
            return { ...module, modules: recursiveUpdate(module.modules, parentId, updateCallback) };
        }
        return module;
    });
};

const recursiveFileUpdate = (
    modules: CourseModule[], 
    moduleId: string, 
    updateCallback: (files: ProductFile[]) => ProductFile[]
): CourseModule[] => {
    if (!modules) return []; // Safety check for undefined modules

    return modules.map(module => {
        if (module.id === moduleId) {
            const currentFiles = Array.isArray(module.files) ? module.files : [];
            return { ...module, files: updateCallback(currentFiles) };
        }
        if (module.modules && module.modules.length > 0) {
            return { ...module, modules: recursiveFileUpdate(module.modules, moduleId, updateCallback) };
        }
        return module;
    });
};

// --- Rich Text Editor Component ---
const RichTextEditor: React.FC<{ value: string; onChange: (html: string) => void }> = ({ value, onChange }) => {
    const editorRef = useRef<HTMLDivElement>(null);
    const [isCleaning, setIsCleaning] = useState(false);
    const isInternalChange = useRef(false);
    const isMounted = useRef(true);

    useEffect(() => {
        isMounted.current = true;
        return () => { isMounted.current = false; };
    }, []);

    useEffect(() => {
        if (isInternalChange.current) {
            isInternalChange.current = false;
            return;
        }
        // Only update if the content is different and we are not focused to prevent loops
        if (editorRef.current && editorRef.current.innerHTML !== value) {
            if (document.activeElement !== editorRef.current) {
                 if (value === '' && editorRef.current.innerHTML !== '') {
                    editorRef.current.innerHTML = '';
                } else if (value) {
                    editorRef.current.innerHTML = value;
                }
            }
        }
    }, [value]);

    const handleInput = () => {
        if (editorRef.current && isMounted.current) {
            isInternalChange.current = true;
            try {
                onChange(editorRef.current.innerHTML);
            } catch (e) {
                console.error("RichTextEditor change error:", e);
            }
        }
    };
    
    const handleBlur = () => {
        // Ensure final content is saved on blur
         if (editorRef.current && isMounted.current) {
             const currentContent = editorRef.current.innerHTML;
             if (currentContent !== value) {
                  isInternalChange.current = true;
                  onChange(currentContent);
             }
         }
    };

    const execCmd = (command: string, value: string | undefined = undefined) => {
        document.execCommand(command, false, value);
        if (editorRef.current) editorRef.current.focus();
    };

    // SMART CLEANER: Aggressively removes MS Word bloat and dangerous tags
    const cleanHTML = (html: string) => {
        if (!html) return '';
        try {
            const tempDiv = document.createElement('div');
            tempDiv.innerHTML = html;

            // 1. Remove scripts, styles, objects, embeds, iframes, forms
            const unsafeTags = ['script', 'style', 'object', 'embed', 'link', 'iframe', 'meta', 'xml', 'form', 'input', 'button'];
            unsafeTags.forEach(tag => {
                const elements = tempDiv.querySelectorAll(tag);
                elements.forEach(el => el.remove());
            });

            // 2. Unwrap and Clean Word-specific tags (namespaces like o:p, w:sdt)
            const allElements = tempDiv.querySelectorAll('*');
            allElements.forEach(el => {
                // Remove attributes that cause bloat or layout issues
                el.removeAttribute('style');
                el.removeAttribute('class');
                el.removeAttribute('align');
                el.removeAttribute('lang');
                el.removeAttribute('face');
                
                // Remove empty tags (except breaks/images)
                if (['BR', 'IMG', 'HR'].indexOf(el.tagName) === -1 && el.innerHTML.trim() === '') {
                   el.remove();
                }
            });
            return tempDiv.innerHTML;
        } catch (e) {
            console.error("HTML cleaning failed", e);
            return html; // Fallback to original if cleaning fails
        }
    };

    const handlePaste = (e: React.ClipboardEvent<HTMLDivElement>) => {
        e.preventDefault();
        setIsCleaning(true);

        try {
            const text = e.clipboardData.getData('text/html') || e.clipboardData.getData('text/plain');
            
            // If HTML exists, clean it. If plain text, wrap in paragraphs.
            const cleanContent = e.clipboardData.types.includes('text/html') 
                ? cleanHTML(text) 
                : text.split('\n').map(line => `<p>${line}</p>`).join('');
            
            document.execCommand('insertHTML', false, cleanContent);
            handleInput();
        } catch (err) {
            console.error("Paste error:", err);
            // Fallback
            const plainText = e.clipboardData.getData('text/plain');
            document.execCommand('insertText', false, plainText);
        }
        
        if (isMounted.current) {
            setTimeout(() => { if (isMounted.current) setIsCleaning(false) }, 500);
        }
    };

    return (
        <div className="border rounded-lg overflow-hidden border-gray-300 bg-white relative">
            {isCleaning && (
                <div className="absolute inset-0 bg-white/90 flex items-center justify-center z-10 border-2 border-blue-500 rounded-lg">
                    <span className="text-blue-600 font-bold animate-pulse flex items-center gap-2">
                        <svg className="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                        Compressing & Cleaning Text...
                    </span>
                </div>
            )}
            {/* Toolbar */}
            <div className="flex flex-wrap gap-1 p-2 bg-gray-100 border-b border-gray-300 sticky top-0 z-10">
                <button type="button" onClick={() => execCmd('bold')} className="p-1.5 hover:bg-gray-200 rounded font-bold" title="Bold">B</button>
                <button type="button" onClick={() => execCmd('italic')} className="p-1.5 hover:bg-gray-200 rounded italic" title="Italic">I</button>
                <button type="button" onClick={() => execCmd('underline')} className="p-1.5 hover:bg-gray-200 rounded underline" title="Underline">U</button>
                <div className="w-px h-6 bg-gray-300 mx-1 self-center"></div>
                <button type="button" onClick={() => execCmd('formatBlock', 'H2')} className="p-1.5 hover:bg-gray-200 rounded font-bold text-sm" title="Heading 2">H2</button>
                <button type="button" onClick={() => execCmd('formatBlock', 'H3')} className="p-1.5 hover:bg-gray-200 rounded font-bold text-xs" title="Heading 3">H3</button>
                <button type="button" onClick={() => execCmd('formatBlock', 'P')} className="p-1.5 hover:bg-gray-200 rounded text-sm" title="Paragraph">P</button>
                <div className="w-px h-6 bg-gray-300 mx-1 self-center"></div>
                <button type="button" onClick={() => execCmd('insertOrderedList')} className="p-1.5 hover:bg-gray-200 rounded" title="Numbered List">1.</button>
                <button type="button" onClick={() => execCmd('insertUnorderedList')} className="p-1.5 hover:bg-gray-200 rounded" title="Bullet List">•</button>
                <div className="w-px h-6 bg-gray-300 mx-1 self-center"></div>
                <button type="button" onClick={() => { const url = prompt('Enter link URL'); if(url) execCmd('createLink', url); }} className="p-1.5 hover:bg-gray-200 rounded text-blue-600 underline" title="Link">Link</button>
            </div>
            
            {/* Editor Area */}
            <div 
                ref={editorRef}
                contentEditable
                onInput={handleInput}
                onPaste={handlePaste}
                onBlur={handleBlur}
                className="p-4 min-h-[300px] max-h-[500px] overflow-y-auto outline-none prose prose-sm max-w-none cursor-text"
                style={{ minHeight: '300px' }}
            />
             <div className="bg-blue-50 p-2 text-xs text-blue-800 border-t border-blue-200 flex justify-between items-center">
                <span><strong>Tip:</strong> Text pasted here is automatically compressed and sanitized.</span>
            </div>
        </div>
    );
};


// --- Child Components ---

const AddContentModal: React.FC<{
    onAdd: (file: Omit<ProductFile, 'id'>) => void;
    onClose: () => void;
}> = ({ onAdd, onClose }) => {
    const fileInputRef = useRef<HTMLInputElement>(null);
    const [uploadConfig, setUploadConfig] = useState<{type: ProductFileType, accept: string} | null>(null);
    const [view, setView] = useState<'selection' | 'form' | 'text-editor'>('selection');
    const [formState, setFormState] = useState<{type: ProductFileType, url: string, name: string, content: string} | null>(null);
    const [isUploading, setIsUploading] = useState(false);
    const [uploadProgress, setUploadProgress] = useState(0);

    const handleFileSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0] && uploadConfig) {
            const file = e.target.files[0];
            
            // FIREBASE UPLOAD LOGIC
            setIsUploading(true);
            setUploadProgress(0);
            
            try {
                // Create a unique filename
                const storageRef = ref(storage, `content/${Date.now()}-${file.name}`);
                
                // Upload
                const snapshot = await uploadBytes(storageRef, file);
                const downloadURL = await getDownloadURL(snapshot.ref);
                
                onAdd({
                    name: file.name,
                    type: uploadConfig.type,
                    url: downloadURL, // We save the Firebase Storage URL, not the big base64 file
                });
                onClose();
                
            } catch (error) {
                console.error("Upload failed:", error);
                alert("File upload failed. Please try again.");
            } finally {
                setIsUploading(false);
            }
        }
        if (fileInputRef.current) fileInputRef.current.value = ""; 
        setUploadConfig(null);
    };

    const triggerFileUpload = (type: ProductFileType, accept: string) => {
        setUploadConfig({ type, accept });
        fileInputRef.current?.click();
    };

    const showLinkForm = (type: ProductFileType) => {
        setFormState({ type, url: '', name: type === 'youtube' ? 'YouTube Video' : '', content: '' });
        setView('form');
    };

    const showTextEditor = () => {
        setFormState({ type: 'ebook', url: '', name: '', content: '' });
        setView('text-editor');
    };

    const handleFormSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        try {
            if (formState) {
                if (view === 'text-editor') {
                    if (formState.name && formState.content) {
                         // Check size limitation (approx 800KB limit to be safe for Firestore 1MB limit)
                        if (formState.content.length > 800000) {
                            alert("Content is too large (over 800KB). Please split it into multiple smaller chapters.");
                            return;
                        }
                        onAdd({ name: formState.name, type: 'ebook', url: '', content: formState.content });
                        onClose();
                    } else {
                        alert("Please provide both a chapter title and content.");
                    }
                } else {
                     if (formState.url && formState.name) {
                        onAdd({ name: formState.name, type: formState.type, url: formState.url });
                        onClose();
                    }
                }
            }
        } catch (err) {
            console.error("Form submit error:", err);
            alert("An error occurred while adding content. Please check the console.");
        }
    };
    
    const contentTypes = [
        { label: 'Write/Paste Article (Formatted Text)', action: showTextEditor, primary: true },
        { label: 'YouTube Video', action: () => showLinkForm('youtube') },
        { label: 'Upload PDF (No Limit)', action: () => triggerFileUpload('pdf', 'application/pdf') },
        { label: 'Upload Video (MP4 - No Limit)', action: () => triggerFileUpload('video', 'video/mp4') },
        { label: 'External Link (Any URL)', action: () => showLinkForm('link') },
    ];
    
    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex justify-center items-center p-4">
            <div className={`bg-white rounded-lg shadow-xl w-full ${view === 'text-editor' ? 'max-w-5xl h-[85vh]' : 'max-w-md'} p-6 relative transition-all duration-300 flex flex-col`}>
                 <button type="button" onClick={onClose} className="absolute top-3 right-3 text-gray-400 hover:text-gray-600 text-2xl font-bold z-10">&times;</button>
                 
                 {isUploading ? (
                     <div className="text-center py-10">
                         <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                         <h3 className="text-xl font-bold text-gray-800">Uploading to Cloud...</h3>
                         <p className="text-gray-500 mt-2">Please wait while your file is being secured.</p>
                     </div>
                 ) : view === 'selection' && (
                    <>
                        <h3 className="text-xl font-bold text-center mb-6 text-gray-800">Add Course Content</h3>
                        <div className="grid grid-cols-1 gap-4 overflow-y-auto">
                            {contentTypes.map(contentType => (
                                <button 
                                    key={contentType.label} 
                                    type="button" 
                                    onClick={contentType.action} 
                                    className={`p-4 border rounded-lg transition-all text-center font-semibold ${contentType.primary ? 'bg-blue-50 border-blue-200 text-blue-700 hover:bg-blue-100 shadow-sm' : 'hover:bg-gray-100 hover:border-blue-500 text-gray-700'}`}
                                >
                                    {contentType.label}
                                    {contentType.primary && <span className="block text-xs font-normal mt-1 text-blue-600">Best for Articles & Chapters</span>}
                                </button>
                            ))}
                        </div>
                        <div className="mt-6 p-3 bg-green-50 border border-green-200 rounded text-xs text-green-800 flex items-center gap-2">
                            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                            <span><strong>Cloud Upload Active:</strong> Large files are now uploaded to secure storage, bypassing local browser limits.</span>
                        </div>
                    </>
                 )}

                 {view === 'text-editor' && formState && (
                     <div className="flex flex-col h-full">
                        <h3 className="text-xl font-bold text-center mb-4 text-gray-800 flex-shrink-0">Create E-book Chapter</h3>
                         <form onSubmit={handleFormSubmit} className="flex flex-col flex-1 space-y-4 overflow-hidden">
                            <div className="flex-shrink-0">
                                <label htmlFor="content-name" className="block text-sm font-medium text-gray-700">Chapter Title</label>
                                <input 
                                    id="content-name"
                                    type="text"
                                    placeholder="e.g., Module 6: Planning & Scripting"
                                    value={formState.name}
                                    onChange={e => setFormState({...formState, name: e.target.value})}
                                    required
                                    className="w-full p-2 border rounded mt-1"
                                />
                            </div>
                            <div className="flex-1 flex flex-col min-h-0">
                                <label className="block text-sm font-medium text-gray-700 mb-1">Content</label>
                                <p className="text-xs text-gray-500 mb-2">
                                    Paste your content here. We will automatically clean up the formatting to keep it lightweight.
                                </p>
                                <div className="flex-1 overflow-hidden flex flex-col">
                                    <RichTextEditor 
                                        value={formState.content || ''}
                                        onChange={(html) => setFormState({...formState, content: html})}
                                    />
                                </div>
                            </div>
                             <div className="flex justify-end space-x-3 pt-4 flex-shrink-0">
                                <button type="button" onClick={() => setView('selection')} className="px-4 py-2 bg-gray-200 rounded hover:bg-gray-300">Back</button>
                                <button type="submit" className="px-6 py-2 bg-blue-600 text-white font-bold rounded hover:bg-blue-700">Save Chapter</button>
                            </div>
                         </form>
                     </div>
                 )}

                 {view === 'form' && formState && (
                    <div className="overflow-y-auto">
                        <h3 className="text-xl font-bold text-center mb-6 text-gray-800">
                            Add {formState.type === 'youtube' ? 'YouTube Video' : 'External Link'}
                        </h3>
                        <form onSubmit={handleFormSubmit} className="space-y-4">
                            <div>
                                <label htmlFor="content-url" className="block text-sm font-medium text-gray-700">Content URL</label>
                                <textarea 
                                    id="content-url"
                                    rows={4}
                                    placeholder={formState.type === 'youtube' ? "Paste YouTube URL..." : "https://..."}
                                    value={formState.url}
                                    onChange={e => setFormState({...formState, url: e.target.value})}
                                    required
                                    className="w-full p-2 border rounded mt-1 font-mono text-sm"
                                />
                            </div>
                             <div>
                                <label htmlFor="content-name" className="block text-sm font-medium text-gray-700">Display Name</label>
                                <input 
                                    id="content-name"
                                    type="text"
                                    placeholder="e.g., Introduction Video"
                                    value={formState.name}
                                    onChange={e => setFormState({...formState, name: e.target.value})}
                                    required
                                    className="w-full p-2 border rounded mt-1"
                                />
                            </div>
                            <div className="flex justify-end space-x-3 pt-4">
                                <button type="button" onClick={() => setView('selection')} className="px-4 py-2 bg-gray-200 rounded hover:bg-gray-300">Back</button>
                                <button type="submit" className="px-6 py-2 bg-blue-600 text-white font-bold rounded hover:bg-blue-700">Add Content</button>
                            </div>
                        </form>
                    </div>
                 )}

                 <input 
                    type="file" 
                    ref={fileInputRef} 
                    className="hidden" 
                    accept={uploadConfig?.accept}
                    onChange={handleFileSelected} 
                 />
            </div>
        </div>
    );
};

interface ModuleEditorProps {
    module: CourseModule;
    onUpdate: (updatedModules: CourseModule[]) => void;
    allModules: CourseModule[];
    level: number;
}

const ModuleEditor: React.FC<ModuleEditorProps> = ({ module, onUpdate, allModules, level }) => {
    const [isAddingContent, setIsAddingContent] = useState(false);

    const handleUpdateTitle = (newTitle: string) => {
        const updateRecursive = (modules: CourseModule[]): CourseModule[] => {
            return modules.map(m => {
                if (m.id === module.id) return { ...m, title: newTitle };
                if (m.modules && m.modules.length > 0) return { ...m, modules: updateRecursive(m.modules) };
                return m;
            });
        };
        onUpdate(updateRecursive(allModules));
    };

    const handleAddSubModule = (parentId: string) => {
        const newModule: CourseModule = {
            id: `mod-${Date.now()}`,
            title: `New Sub-Module`,
            files: [],
            modules: []
        };
        const updated = recursiveUpdate(allModules, parentId, (modules) => [...modules, newModule]);
        onUpdate(updated);
    };
    
    const handleAddContent = (fileData: Omit<ProductFile, 'id'>) => {
        const newFile: ProductFile = {
            ...fileData,
            id: `file-${Date.now()}`,
        };
        const updated = recursiveFileUpdate(allModules, module.id, (files) => [...files, newFile]);
        onUpdate(updated);
        setIsAddingContent(false);
    };

    const handleRemoveFile = (fileId: string) => {
        const updated = recursiveFileUpdate(allModules, module.id, (files) => files.filter(f => f.id !== fileId));
        onUpdate(updated);
    };
    
    const handleDeleteModule = (moduleId: string) => {
        if (!window.confirm("Are you sure? This will delete the module and all its content.")) return;
        
        const deleteRecursive = (modules: CourseModule[]): CourseModule[] => {
            if (!modules) return [];
            return modules.filter(m => m.id !== moduleId).map(m => ({
                ...m,
                modules: deleteRecursive(m.modules || [])
            }));
        }
        onUpdate(deleteRecursive(allModules));
    };

    return (
        <div className={`p-4 rounded-lg border-2 mt-4 ${level === 0 ? 'bg-blue-50 border-blue-200' : 'bg-white border-gray-200'}`}>
            {/* Module Header */}
            <div className="flex justify-between items-center pb-2 border-b border-gray-300">
                <input 
                    type="text"
                    value={module.title}
                    onChange={(e) => handleUpdateTitle(e.target.value)}
                    className="font-bold text-xl text-gray-800 bg-transparent border-none focus:ring-0 w-full p-0"
                    placeholder="Module Title"
                />
                <button 
                    type="button" 
                    onClick={() => handleDeleteModule(module.id)} 
                    className="text-sm text-red-500 hover:text-red-700 font-semibold flex-shrink-0 ml-4 px-3 py-1 border border-red-200 rounded-md hover:bg-red-50 transition-colors"
                >
                    DELETE MODULE
                </button>
            </div>

            <div className="pl-4 mt-4">
                {/* Content (Files) */}
                <div>
                    <h4 className="font-semibold text-gray-600 text-sm uppercase tracking-wider">Content</h4>
                    <div className="space-y-2 mt-2">
                        {(module.files || []).map(file => (
                            <div key={file.id} className="flex items-center justify-between bg-white p-2 rounded-md border text-sm shadow-sm">
                               <div className="flex items-center gap-2">
                                    {file.type === 'ebook' && <span className="bg-purple-100 text-purple-800 text-xs px-2 py-0.5 rounded font-bold">Rich Text</span>}
                                    <span className="text-gray-700">{file.name} <span className="text-gray-400">({file.type})</span></span>
                               </div>
                               <button type="button" onClick={() => handleRemoveFile(file.id)} className="text-red-500 hover:text-red-700 font-bold text-lg leading-none p-1">&times;</button>
                            </div>
                        ))}
                        {(module.files || []).length === 0 && (module.modules || []).length === 0 && (
                            <p className="text-sm text-gray-400 italic py-2">This module is empty.</p>
                        )}
                         <button type="button" onClick={() => setIsAddingContent(true)} className="mt-3 text-sm font-semibold text-blue-600 hover:text-blue-800 transition-colors flex items-center">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-11a1 1 0 10-2 0v2H7a1 1 0 100 2h2v2a1 1 0 102 0v-2h2a1 1 0 100-2h-2V7z" clipRule="evenodd" /></svg>
                            Add Content (Text, Video, PDF)
                         </button>
                    </div>
                </div>
                
                {/* Sub-modules */}
                <div className="mt-4">
                     <h4 className="font-semibold text-gray-600 text-sm uppercase tracking-wider">Sub-modules</h4>
                     <div className={`border-l-4 pl-4 ${level % 2 === 0 ? 'border-green-200' : 'border-purple-200'}`}>
                        {(module.modules || []).map(subModule => (
                           <ModuleEditor 
                               key={subModule.id}
                               module={subModule}
                               onUpdate={onUpdate}
                               allModules={allModules}
                               level={level + 1}
                           />
                       ))}
                        <button type="button" onClick={() => handleAddSubModule(module.id)} className="mt-3 text-sm font-semibold text-green-600 hover:text-green-800 transition-colors flex items-center">
                           <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-11a1 1 0 10-2 0v2H7a1 1 0 100 2h2v2a1 1 0 102 0v-2h2a1 1 0 100-2h-2V7z" clipRule="evenodd" /></svg>
                           Add Sub-module (Folder)
                       </button>
                    </div>
                </div>
            </div>
            {isAddingContent && <AddContentModal onAdd={handleAddContent} onClose={() => setIsAddingContent(false)} />}
        </div>
    );
};

const CouponSelectionModal: React.FC<{
    coupons: Coupon[];
    onSelect: (code: string) => void;
    onClose: () => void;
    triggerRef: React.RefObject<HTMLButtonElement>;
}> = ({ coupons, onSelect, onClose, triggerRef }) => {
    const [style, setStyle] = useState<React.CSSProperties>({ opacity: 0 }); // Initially invisible
    const modalRef = useRef<HTMLDivElement>(null);

    useLayoutEffect(() => {
        if (triggerRef.current && modalRef.current) {
            const buttonRect = triggerRef.current.getBoundingClientRect();
            const modalHeight = modalRef.current.offsetHeight;
            const modalWidth = modalRef.current.offsetWidth;
            
            // Default position: above the button
            let top = buttonRect.top - modalHeight - 8; // 8px gap

            // If not enough space above, position below
            if (top < 8) {
                top = buttonRect.bottom + 8;
            }

            // Center horizontally relative to the button
            let left = buttonRect.left + (buttonRect.width / 2) - (modalWidth / 2);

            // Clamp to viewport edges
            left = Math.max(8, Math.min(left, window.innerWidth - modalWidth - 8));

            setStyle({
                position: 'fixed',
                top: `${top}px`,
                left: `${left}px`,
                opacity: 1, // Make it visible after positioning
            });
        }
    }, [triggerRef]);

    // New availability check function
    const isCouponAvailable = (c: Coupon): boolean => {
        if (!c.isActive || c.timesUsed >= c.usageLimit) {
            return false;
        }
        try {
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            const [year, month, day] = c.expiryDate.split('-').map(Number);
            const expiry = new Date(year, month - 1, day);
            expiry.setHours(23, 59, 59, 999);
            if (expiry < today) {
                return false;
            }
        } catch (e) {
            console.error("Invalid date format for coupon:", c);
            return false;
        }
        return true;
    };
    
    const getUnavailableReason = (c: Coupon): string => {
        if (!c.isActive) return "Inactive";
        if (c.timesUsed >= c.usageLimit) return "Usage limit reached";
        
        try {
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            const [year, month, day] = c.expiryDate.split('-').map(Number);
            const expiry = new Date(year, month - 1, day);
            expiry.setHours(23, 59, 59, 999);
            if (expiry < today) return "Expired";
        } catch (e) {
            return "Invalid date";
        }
        return "Unknown reason";
    }

    // Sort coupons to show available ones first
    const sortedCoupons = [...coupons].sort((a, b) => {
        const aIsAvailable = isCouponAvailable(a);
        const bIsAvailable = isCouponAvailable(b);
        if (aIsAvailable && !bIsAvailable) return -1;
        if (!aIsAvailable && bIsAvailable) return 1;
        return 0;
    });

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-[51]" onClick={onClose}>
            <div
                ref={modalRef}
                style={style}
                onClick={e => e.stopPropagation()}
                className="absolute bg-white rounded-lg shadow-2xl w-[350px] max-h-[60vh] flex flex-col transition-opacity duration-150 animate-pop-in"
            >
                <div className="p-4 border-b flex justify-between items-center flex-shrink-0">
                    <h3 className="text-lg font-bold text-gray-800">Select a Coupon to Associate</h3>
                    <button type="button" onClick={onClose} className="text-gray-400 hover:text-gray-600 font-bold text-2xl">&times;</button>
                </div>
                <div className="p-4 overflow-y-auto">
                    {coupons.length > 0 ? (
                        <div className="space-y-2">
                            {sortedCoupons.map(coupon => {
                                const available = isCouponAvailable(coupon);
                                return (
                                    <button
                                        key={coupon.id}
                                        onClick={() => onSelect(coupon.code)}
                                        disabled={!available}
                                        className="w-full text-left p-3 border rounded-lg transition-colors disabled:opacity-60 disabled:cursor-not-allowed disabled:bg-gray-50 enabled:hover:bg-blue-50 enabled:hover:border-blue-300"
                                    >
                                        <div className="flex justify-between items-center">
                                            <p className="font-bold font-mono text-primary">{coupon.code}</p>
                                            {available ? (
                                                <span className="text-xs font-semibold px-2 py-1 rounded-full bg-green-100 text-green-800">Available</span>
                                            ) : (
                                                <span className="text-xs font-semibold px-2 py-1 rounded-full bg-gray-200 text-gray-600">Unavailable</span>
                                            )}
                                        </div>
                                        <p className="text-sm text-gray-600 mt-1">
                                            Discount: {coupon.type === 'percentage' ? `${coupon.value}%` : `₹${coupon.value} OFF`} | Expires: {new Date(coupon.expiryDate).toLocaleDateString()}
                                        </p>
                                        {!available && <p className="text-xs text-red-500 mt-1">Reason: {getUnavailableReason(coupon)}</p>}
                                    </button>
                                );
                            })}
                        </div>
                    ) : (
                        <p className="text-center text-gray-500 py-8">No coupons have been created. Create one in the Coupon Management section.</p>
                    )}
                </div>
            </div>
        </div>
    );
};


const ProductForm: React.FC<{
    product?: ProductWithRating | null;
    coupons: Coupon[];
    onSave: (product: Omit<Product, 'id'>) => void;
    onCancel: () => void;
}> = ({ product, coupons, onSave, onCancel }) => {
    const [formData, setFormData] = useState({
        title: product?.title || '',
        description: product?.description || '',
        longDescription: product?.longDescription || '',
        price: product?.price || '₹',
        salePrice: product?.salePrice || '',
        imageSeed: product?.imageSeed || '',
        category: product?.category || '',
        department: product?.department || 'Unisex',
        inStock: product?.inStock === undefined ? true : product.inStock,
        manualRating: (product?.manualRating !== null && product?.manualRating !== undefined) ? product.manualRating.toString() : '',
        sku: product?.sku || '',
        dimensions: product?.dimensions || '',
        fileFormat: product?.fileFormat || '',
        aspectRatio: product?.aspectRatio || 'aspect-[4/3]',
        isFree: product?.isFree || false,
        couponCode: product?.couponCode || '',
    });
    
    const [features, setFeatures] = useState<string[]>(product?.features || []);
    const [currentFeature, setCurrentFeature] = useState('');
    
    const [tags, setTags] = useState<string[]>(product?.tags || []);
    const [currentTag, setCurrentTag] = useState('');

    const [modules, setModules] = useState<CourseModule[]>(product?.courseContent || []);
    const [images, setImages] = useState<string[]>(product?.images || []);
    
    const [preFreePrice, setPreFreePrice] = useState(product?.price || '₹0');
    const [isCouponModalOpen, setIsCouponModalOpen] = useState(false);
    const couponButtonRef = useRef<HTMLButtonElement>(null);

    useEffect(() => {
        if (formData.isFree) {
            setFormData(prev => {
                // Only update preFreePrice if it's not already the 'free' price
                if (prev.price !== '₹3') {
                    setPreFreePrice(prev.price);
                }
                return { ...prev, price: '₹3', salePrice: '' };
            });
        } else {
            // Restore the price only if the current price is the free price
            if(formData.price === '₹3') {
                setFormData(prev => ({ ...prev, price: preFreePrice }));
            }
        }
    }, [formData.isFree]);


    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { name, value, type } = e.target;
        if (type === 'checkbox') {
            const { checked } = e.target as HTMLInputElement;
            setFormData(prev => ({ ...prev, [name]: checked }));
        } else if (name === 'price' || name === 'salePrice') {
             const numericValue = value.replace(/[^0-9.]/g, '');
             if (name === 'price') {
                 setFormData(prev => ({...prev, price: `₹${numericValue}`}));
             } else { // salePrice
                 // Allow empty value for salePrice to remove it
                 const formattedValue = numericValue ? `₹${numericValue}` : '';
                 setFormData(prev => ({...prev, salePrice: formattedValue}));
             }
        }
        else {
             setFormData(prev => ({ ...prev, [name]: value }));
        }
    };
    
    const handleAddFeature = () => {
        if (currentFeature.trim() !== '' && !features.includes(currentFeature.trim())) {
            setFeatures([...features, currentFeature.trim()]);
            setCurrentFeature('');
        }
    };

    const handleRemoveFeature = (featureToRemove: string) => {
        setFeatures(features.filter(f => f !== featureToRemove));
    };

    const handleAddTag = () => {
        if (currentTag.trim() !== '' && !tags.includes(currentTag.trim())) {
            setTags([...tags, currentTag.trim().toLowerCase()]);
            setCurrentTag('');
        }
    };

    const handleRemoveTag = (tagToRemove: string) => {
        setTags(tags.filter(t => t !== tagToRemove));
    };

     // --- Module Management ---
    const handleAddTopLevelModule = () => {
        const newModule: CourseModule = {
            id: `mod-${Date.now()}`,
            title: `New Module ${modules.length + 1}`,
            files: [],
            modules: []
        };
        setModules(prev => [...prev, newModule]);
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        
        const finalData = {
            ...formData,
            features,
            tags,
            images,
            imageSeed: formData.imageSeed || formData.title.toLowerCase().replace(/\s+/g, '-'),
            manualRating: formData.manualRating === '' ? null : parseFloat(formData.manualRating),
            courseContent: modules,
            isVisible: product?.isVisible ?? true, // Preserve if editing, default to true if new
        };
        onSave(finalData);
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center p-4 animate-fade-in">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-3xl max-h-[90vh] overflow-y-auto animate-scale-in-up">
                <form onSubmit={handleSubmit} className="p-8">
                    <h2 className="text-2xl font-bold text-gray-800 mb-6">{product ? 'Edit Product' : 'Add New Product'}</h2>
                    
                    {/* Basic Information Section */}
                    <details className="border-b pb-6 mb-6" open>
                        <summary className="text-lg font-semibold text-gray-700 mb-4 cursor-pointer">Basic Information</summary>
                        <div className="space-y-4 mt-4">
                            <input name="title" value={formData.title} onChange={handleChange} placeholder="Product Title" required className="w-full p-2 border rounded" />
                            <textarea name="description" value={formData.description} onChange={handleChange} placeholder="Short Description (for product cards)" required className="w-full p-2 border rounded" rows={2}></textarea>
                            <textarea name="longDescription" value={formData.longDescription} onChange={handleChange} placeholder="Long Description (for detail page)" required className="w-full p-2 border rounded" rows={4}></textarea>
                        </div>
                    </details>

                     {/* Pricing & Inventory Section */}
                    <details className="border-b pb-6 mb-6" open>
                        <summary className="text-lg font-semibold text-gray-700 mb-4 cursor-pointer">Pricing & Inventory</summary>
                         <div className="mt-4 p-4 rounded-lg bg-yellow-50 border border-yellow-200">
                             <label className="flex items-center space-x-3 cursor-pointer">
                                 <input type="checkbox" name="isFree" checked={formData.isFree} onChange={handleChange} className="form-checkbox h-5 w-5 text-blue-600 rounded focus:ring-blue-500"/>
                                 <span className="font-semibold text-yellow-800">Mark as Free (sets price to ₹3)</span>
                             </label>
                         </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                            <div>
                                <label className="text-sm font-medium text-gray-600">Original Price</label>
                                <input name="price" value={formData.price} onChange={handleChange} placeholder="Original Price" required className="w-full p-2 border rounded" disabled={formData.isFree} />
                            </div>
                            <div>
                                <label className="text-sm font-medium text-gray-600">Sale Price (Optional)</label>
                                <input name="salePrice" value={formData.salePrice} onChange={handleChange} placeholder="Sale Price (e.g., ₹299)" className="w-full p-2 border rounded" disabled={formData.isFree} />
                            </div>
                            <input name="sku" value={formData.sku} onChange={handleChange} placeholder="SKU (e.g., EBOOK-001)" className="w-full p-2 border rounded" />
                        </div>
                         <div className="flex items-center space-x-3 pt-4">
                             <label htmlFor="inStock" className="font-medium text-gray-700">Stock Status:</label>
                             <label className="relative inline-flex items-center cursor-pointer">
                                <input type="checkbox" id="inStock" name="inStock" checked={formData.inStock} onChange={handleChange} className="sr-only peer" />
                                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
                                <span className="ml-3 text-sm font-medium text-gray-900">{formData.inStock ? "In Stock" : "Out of Stock"}</span>
                            </label>
                        </div>
                    </details>
                    
                    {/* Coupon Association Section */}
                    <details className="border-b pb-6 mb-6" open>
                        <summary className="text-lg font-semibold text-gray-700 mb-4 cursor-pointer">Coupon Association</summary>
                        <div className="mt-4 p-4 rounded-lg bg-gray-50 border">
                            <div className="flex justify-between items-center">
                                <div>
                                    <p className="text-sm font-medium text-gray-600">Associated Coupon:</p>
                                    {formData.couponCode ? (
                                        <span className="font-bold font-mono text-primary bg-blue-100 px-2 py-1 rounded-md">{formData.couponCode}</span>
                                    ) : (
                                        <span className="text-gray-500 italic">None</span>
                                    )}
                                </div>
                                <div className="flex gap-2">
                                     <button type="button" onClick={() => setFormData(prev => ({...prev, couponCode: ''}))} className="px-3 py-2 text-sm bg-red-100 text-red-700 font-semibold rounded hover:bg-red-200">Remove</button>
                                    <button ref={couponButtonRef} type="button" onClick={() => setIsCouponModalOpen(true)} className="px-3 py-2 text-sm bg-blue-100 text-blue-700 font-semibold rounded hover:bg-blue-200">Select Coupon</button>
                                </div>
                            </div>
                            <p className="text-xs text-gray-500 mt-2">Associate a coupon to highlight it on the product page (feature to be implemented on the customer-facing side).</p>
                        </div>
                    </details>


                    {/* Details & Attributes Section */}
                    <details className="border-b pb-6 mb-6">
                        <summary className="text-lg font-semibold text-gray-700 mb-4 cursor-pointer">Details & Attributes</summary>
                         <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                           <input name="category" value={formData.category} onChange={handleChange} placeholder="Category" className="w-full p-2 border rounded" />
                           <div>
                               <label className="text-sm font-medium text-gray-600">Department</label>
                               <select name="department" value={formData.department} onChange={handleChange} className="w-full p-2 border rounded">
                                   <option value="Unisex">Unisex</option>
                                   <option value="Men">Men</option>
                                   <option value="Women">Women</option>
                               </select>
                           </div>
                           <input name="dimensions" value={formData.dimensions} onChange={handleChange} placeholder="Dimensions (e.g., 150 pages)" className="w-full p-2 border rounded" />
                           <input name="fileFormat" value={formData.fileFormat} onChange={handleChange} placeholder="File Format (e.g., PDF, MP4)" className="w-full p-2 border rounded" />
                        </div>
                        
                        <div className="mt-4">
                            <label className="block text-sm font-medium text-gray-700">Features</label>
                            <div className="flex mt-1">
                                <input
                                    type="text"
                                    value={currentFeature}
                                    onChange={(e) => setCurrentFeature(e.target.value)}
                                    placeholder="Add a feature"
                                    className="w-full p-2 border rounded-l-md"
                                    onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); handleAddFeature(); } }}
                                />
                                <button type="button" onClick={handleAddFeature} className="px-4 py-2 bg-gray-200 rounded-r-md hover:bg-gray-300">Add</button>
                            </div>
                             <div className="mt-2 flex flex-wrap gap-2">
                                {features.map((f, i) => (
                                    <div key={i} className="bg-blue-100 text-blue-800 text-sm font-medium px-2.5 py-1 rounded-full flex items-center gap-2">
                                        {f}
                                        <button type="button" onClick={() => handleRemoveFeature(f)} className="text-blue-800 hover:text-blue-900">&times;</button>
                                    </div>
                                ))}
                            </div>
                        </div>

                        <div className="mt-4">
                            <label className="block text-sm font-medium text-gray-700">Tags / Keywords</label>
                            <div className="flex mt-1">
                                <input
                                    type="text"
                                    value={currentTag}
                                    onChange={(e) => setCurrentTag(e.target.value)}
                                    placeholder="Add a tag"
                                    className="w-full p-2 border rounded-l-md"
                                    onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); handleAddTag(); } }}
                                />
                                <button type="button" onClick={handleAddTag} className="px-4 py-2 bg-gray-200 rounded-r-md hover:bg-gray-300">Add</button>
                            </div>
                             <div className="mt-2 flex flex-wrap gap-2">
                                {tags.map((t, i) => (
                                    <div key={i} className="bg-green-100 text-green-800 text-sm font-medium px-2.5 py-1 rounded-full flex items-center gap-2">
                                        {t}
                                        <button type="button" onClick={() => handleRemoveTag(t)} className="text-green-800 hover:text-green-900">&times;</button>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </details>

                    {/* Course Content Builder Section */}
                    <details className="border-b pb-6 mb-6" open>
                        <summary className="text-lg font-semibold text-gray-700 mb-4 cursor-pointer">Course Content & Files</summary>
                         <div className="mt-4 p-4 bg-gray-100 rounded-lg border space-y-2">
                             {modules.map((module) => (
                                <ModuleEditor key={module.id} module={module} onUpdate={setModules} allModules={modules} level={0} />
                             ))}
                             <button type="button" onClick={handleAddTopLevelModule} className="w-full mt-4 px-4 py-2 bg-blue-100 text-blue-800 font-semibold rounded-lg hover:bg-blue-200">
                                + Add Top-Level Module
                             </button>
                         </div>
                    </details>

                    {/* Media and Rating Section */}
                     <details className="border-b pb-6 mb-6">
                        <summary className="text-lg font-semibold text-gray-700 mb-4 cursor-pointer">Images & Rating</summary>
                        <div className="mt-4">
                             <label className="block text-sm font-medium text-gray-700">Product Image URLs</label>
                             <textarea value={images.join('\n')} onChange={(e) => setImages(e.target.value.split('\n'))} rows={4} className="w-full p-2 border rounded font-mono text-sm" placeholder="Enter one image URL per line. The first line is the primary image."></textarea>
                        </div>
                        <div className="mt-4">
                             <label htmlFor="manualRating" className="block text-sm font-medium text-gray-700">Manual Display Rating</label>
                             <input
                                id="manualRating"
                                name="manualRating"
                                type="number"
                                step="0.1"
                                min="0"
                                max="5"
                                value={formData.manualRating}
                                onChange={handleChange}
                                placeholder="e.g., 4.5"
                                className="mt-1 w-full p-2 border rounded"
                            />
                            <p className="mt-1 text-xs text-gray-500">Leave empty to use the calculated rating from customer reviews.</p>
                            {product && (
                                <p className="mt-1 text-xs text-green-600 font-semibold">
                                    Current calculated rating is: {product.calculatedRating.toFixed(1)} stars from {product.reviewCount} reviews.
                                </p>
                            )}
                        </div>
                        <div className="mt-4">
                            <label htmlFor="imageSeed" className="block text-sm font-medium text-gray-700">Image Seed (for fallback)</label>
                            <input id="imageSeed" name="imageSeed" value={formData.imageSeed} onChange={handleChange} placeholder="e.g., my-cool-product" className="mt-1 w-full p-2 border rounded" />
                             <p className="mt-1 text-xs text-gray-500">Used to generate a placeholder image if no custom thumbnail is uploaded.</p>
                        </div>

                        <div className="mt-4">
                          <label htmlFor="aspectRatio" className="block text-sm font-medium text-gray-700">Thumbnail Aspect Ratio</label>
                          <select
                              id="aspectRatio"
                              name="aspectRatio"
                              value={formData.aspectRatio}
                              onChange={handleChange}
                              className="mt-1 w-full p-2 border rounded"
                          >
                              <option value="aspect-[4/3]">Landscape (4:3)</option>
                              <option value="aspect-square">Square (1:1)</option>
                              <option value="aspect-[3/4]">Portrait (3:4)</option>
                              <option value="aspect-video">Widescreen (16:9)</option>
                              <option value="aspect-[9/16]">Tall (9:16)</option>
                          </select>
                      </div>
                    </details>

                    <div className="mt-6 flex justify-end space-x-4 border-t pt-6">
                        <button type="button" onClick={onCancel} className="px-4 py-2 bg-gray-200 rounded hover:bg-gray-300">Cancel</button>
                        <button type="submit" className="px-6 py-2 bg-razorpay-light-blue text-white font-bold rounded hover:bg-blue-700">Save Product</button>
                    </div>
                </form>
                {isCouponModalOpen && (
                    <CouponSelectionModal
                        coupons={coupons}
                        onSelect={(code) => {
                            setFormData(prev => ({...prev, couponCode: code}));
                            setIsCouponModalOpen(false);
                        }}
                        onClose={() => setIsCouponModalOpen(false)}
                        triggerRef={couponButtonRef}
                    />
                )}
            </div>
        </div>
    );
};

const ProductManagement: React.FC<{
    products: ProductWithRating[];
    users: User[];
    coupons: Coupon[];
    onAddProduct: (product: Omit<Product, 'id'>) => void;
    onUpdateProduct: (product: Product) => void;
    onDeleteProduct: (id: number) => void;
}> = ({ products, users, coupons, onAddProduct, onUpdateProduct, onDeleteProduct }) => {
    const [isFormOpen, setIsFormOpen] = useState(false);
    const [editingProduct, setEditingProduct] = useState<ProductWithRating | null>(null);
    const [newProductForEmail, setNewProductForEmail] = useState<ProductWithRating | null>(null);

    const handleAddNew = () => {
        setEditingProduct(null);
        setIsFormOpen(true);
    };

    const handleEdit = (product: ProductWithRating) => {
        setEditingProduct(product);
        setIsFormOpen(true);
    };

    const handleSave = (productData: Omit<Product, 'id'>) => {
        if (editingProduct) {
            onUpdateProduct({ ...productData, id: editingProduct.id });
        } else {
            onAddProduct(productData);
            const tempNewProduct: ProductWithRating = {
                ...productData,
                id: Date.now(), // This is temporary, for display in the modal only
                rating: productData.manualRating || 0,
                reviewCount: 0,
                calculatedRating: 0
            };
            setNewProductForEmail(tempNewProduct);
        }
        setIsFormOpen(false);
        setEditingProduct(null);
    };

    const handleDelete = (id: number) => {
        if (window.confirm('Are you sure you want to delete this product? This action is permanent.')) {
            onDeleteProduct(id);
        }
    };

    const handleToggleVisibility = (productToToggle: ProductWithRating) => {
        onUpdateProduct({
            ...productToToggle,
            isVisible: productToToggle.isVisible === false ? true : false, // toggle, considering undefined as true
        });
    };

    const relatedProductsForEmail = newProductForEmail
        ? products.filter(p => p.category === newProductForEmail.category && p.id !== newProductForEmail.id).slice(0, 3)
        : [];

    return (
        <div>
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-3xl font-bold text-gray-800">Product Management</h1>
                <button onClick={handleAddNew} className="bg-razorpay-light-blue text-white font-semibold px-5 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                    + Add New Product
                </button>
            </div>

            <div className="bg-white shadow-md rounded-lg overflow-x-auto">
                <table className="w-full min-w-max text-left">
                    <thead className="bg-gray-100">
                        <tr>
                            <th className="p-4 font-semibold">Title</th>
                             <th className="p-4 font-semibold">SKU</th>
                             <th className="p-4 font-semibold">Stock</th>
                             <th className="p-4 font-semibold">Visible</th>
                            <th className="p-4 font-semibold">Price</th>
                            <th className="p-4 font-semibold">Coupon</th>
                            <th className="p-4 font-semibold">Rating</th>
                             <th className="p-4 font-semibold">Tags</th>
                            <th className="p-4 font-semibold">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {products.map(product => (
                            <tr key={product.id} className="border-b hover:bg-gray-50">
                                <td className="p-4 font-medium text-gray-800">{product.title}</td>
                                 <td className="p-4 text-gray-600 font-mono text-xs">{product.sku || 'N/A'}</td>
                                <td className="p-4">
                                     <span className={`text-xs font-semibold px-2 py-1 rounded-full ${
                                            product.inStock 
                                            ? 'bg-green-100 text-green-800'
                                            : 'bg-red-100 text-red-800'
                                        }`}>
                                            {product.inStock ? 'In Stock' : 'Out of Stock'}
                                    </span>
                                </td>
                                 <td className="p-4">
                                    <label className="relative inline-flex items-center cursor-pointer">
                                        <input 
                                            type="checkbox" 
                                            checked={product.isVisible !== false}
                                            onChange={() => handleToggleVisibility(product)}
                                            className="sr-only peer" 
                                        />
                                        <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
                                    </label>
                                </td>
                                <td className="p-4">
                                    {product.isFree ? (
                                        <span className="font-bold text-green-600 bg-green-100 px-2 py-1 rounded-full text-xs">FREE</span>
                                    ) : product.salePrice ? (
                                        <div className="flex flex-col">
                                            <span className="font-bold text-red-600">{product.salePrice}</span>
                                            <span className="text-xs text-gray-500 line-through">{product.price}</span>
                                        </div>
                                    ) : (
                                        <span>{product.price}</span>
                                    )}
                                </td>
                                <td className="p-4">
                                    {product.couponCode ? (
                                        <span className="font-mono text-xs bg-blue-100 text-blue-800 font-semibold px-2 py-1 rounded-full">{product.couponCode}</span>
                                    ) : (
                                        <span className="text-xs text-gray-400">N/A</span>
                                    )}
                                </td>
                                <td className="p-4">
                                    <div className="flex items-center gap-2 mb-1">
                                        <span className="text-xl font-bold text-gray-800">{product.rating.toFixed(1)}</span>
                                        <span className={`text-xs font-semibold px-2 py-1 rounded-full ${
                                            (product.manualRating !== null && product.manualRating !== undefined)
                                            ? 'bg-blue-100 text-blue-800'
                                            : 'bg-green-100 text-green-800'
                                        }`}>
                                            {(product.manualRating !== null && product.manualRating !== undefined) ? 'Manual' : 'Auto'}
                                        </span>
                                    </div>
                                    <div className="text-xs text-gray-500">
                                        from {product.reviewCount} reviews
                                    </div>
                                </td>
                                 <td className="p-4">
                                    <div className="flex flex-wrap gap-1 max-w-xs">
                                        {product.tags?.map(tag => (
                                            <span key={tag} className="text-xs bg-gray-200 text-gray-700 px-2 py-0.5 rounded-full">{tag}</span>
                                        ))}
                                    </div>
                                </td>
                                <td className="p-4 space-x-2">
                                    <button onClick={() => handleEdit(product)} className="text-blue-600 hover:underline">Edit</button>
                                    <button onClick={() => handleDelete(product.id)} className="text-red-600 hover:underline">Delete</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {isFormOpen && (
                <ProductForm
                    product={editingProduct}
                    coupons={coupons}
                    onSave={handleSave}
                    onCancel={() => setIsFormOpen(false)}
                />
            )}

            {newProductForEmail && (
                <NewProductEmailPreviewModal
                    product={newProductForEmail}
                    relatedProducts={relatedProductsForEmail}
                    users={users}
                    onClose={() => setNewProductForEmail(null)}
                />
            )}
        </div>
    );
};

export default ProductManagement;