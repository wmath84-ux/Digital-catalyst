import React, { useState } from 'react';
import { Order } from '../../App';


const StatusBadge: React.FC<{ status: Order['status'] }> = ({ status }) => {
    const baseClasses = "text-xs font-semibold px-2.5 py-1 rounded-full";
    const statusClasses = {
        Completed: "bg-green-100 text-green-800",
        Shipped: "bg-blue-100 text-blue-800",
        Pending: "bg-yellow-100 text-yellow-800",
        Cancelled: "bg-red-100 text-red-800",
    };
    return <span className={`${baseClasses} ${statusClasses[status]}`}>{status}</span>;
};

const OrderDetailModal: React.FC<{ order: Order; onClose: () => void }> = ({ order, onClose }) => {
    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex justify-center items-center p-4">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
                <div className="p-6 border-b flex justify-between items-center">
                    <h2 className="text-xl font-bold text-gray-800">Order Details: <span className="font-mono text-blue-600">{order.id}</span></h2>
                    <button onClick={onClose} className="text-gray-400 hover:text-gray-600 font-bold text-2xl">&times;</button>
                </div>
                <div className="p-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <h3 className="font-semibold text-gray-700 mb-2">Customer</h3>
                            <p className="text-sm text-gray-600">{order.customerName}</p>
                            <p className="text-sm text-gray-500">{order.customerEmail}</p>
                        </div>
                        <div>
                            <h3 className="font-semibold text-gray-700 mb-2">Order Info</h3>
                            <p className="text-sm text-gray-600"><strong>Date:</strong> {new Date(order.date).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
                            <p className="text-sm text-gray-600 flex items-center"><strong>Status:</strong> <span className="ml-2"><StatusBadge status={order.status} /></span></p>
                        </div>
                         <div className="md:col-span-2">
                            <h3 className="font-semibold text-gray-700 mb-2">Billing Address</h3>
                            <p className="text-sm text-gray-500">{order.billingAddress}</p>
                        </div>
                    </div>
                    <div className="mt-6">
                         <h3 className="font-semibold text-gray-700 mb-2">Items Ordered</h3>
                         <div className="border rounded-lg overflow-hidden">
                             <table className="w-full text-sm">
                                 <thead className="bg-gray-50">
                                     <tr>
                                         <th className="p-3 text-left font-medium">Product</th>
                                         <th className="p-3 text-center font-medium">Quantity</th>
                                         <th className="p-3 text-right font-medium">Price</th>
                                     </tr>
                                 </thead>
                                 <tbody>
                                     {order.items.map(item => (
                                         <tr key={item.id} className="border-b">
                                             <td className="p-3">{item.name}</td>
                                             <td className="p-3 text-center">{item.quantity}</td>
                                             <td className="p-3 text-right">{item.price}</td>
                                         </tr>
                                     ))}
                                 </tbody>
                                 <tfoot className="font-bold">
                                     <tr className="bg-gray-50">
                                        <td colSpan={2} className="p-3 text-right">Total</td>
                                        <td className="p-3 text-right">{order.total}</td>
                                     </tr>
                                 </tfoot>
                             </table>
                         </div>
                    </div>
                </div>
                <div className="p-6 bg-gray-50 border-t flex justify-end">
                     <button onClick={onClose} className="px-5 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300">Close</button>
                </div>
            </div>
        </div>
    );
};


const OrderManagement: React.FC<{ orders: Order[] }> = ({ orders }) => {
    const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

    return (
        <div>
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-3xl font-bold text-gray-800">Order Management</h1>
                 <div className="flex space-x-2">
                    <button className="bg-white border border-gray-300 text-gray-700 font-semibold px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors text-sm">
                        Export CSV
                    </button>
                </div>
            </div>

            <div className="mb-6 bg-blue-50 border-l-4 border-blue-500 text-blue-800 p-4 rounded-r-lg" role="alert">
                <p className="font-bold">Demonstration Page</p>
                <p className="text-sm">This is a visual demonstration of the Order Management page using sample data. To show real customer orders, this table must be connected to a backend database.</p>
            </div>

            <div className="bg-white shadow-md rounded-lg overflow-x-auto">
                 <table className="w-full min-w-max text-left">
                    <thead className="bg-gray-100">
                        <tr>
                            <th className="p-4 font-semibold text-sm">Order ID</th>
                            <th className="p-4 font-semibold text-sm">Customer</th>
                            <th className="p-4 font-semibold text-sm">Date</th>
                            <th className="p-4 font-semibold text-sm">Total</th>
                            <th className="p-4 font-semibold text-sm">Status</th>
                            <th className="p-4 font-semibold text-sm">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {orders.map(order => (
                            <tr key={order.id} className="border-b hover:bg-gray-50">
                                <td className="p-4 font-mono text-xs font-medium text-blue-600">{order.id}</td>
                                <td className="p-4">
                                    <p className="font-medium text-gray-800 text-sm">{order.customerName}</p>
                                    <p className="text-xs text-gray-500">{order.customerEmail}</p>
                                </td>
                                <td className="p-4 text-sm text-gray-600">
                                    {new Date(order.date).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
                                </td>
                                <td className="p-4 text-sm font-medium text-gray-800">{order.total}</td>
                                <td className="p-4">
                                    <StatusBadge status={order.status} />
                                </td>
                                <td className="p-4 space-x-2">
                                    <button onClick={() => setSelectedOrder(order)} className="text-blue-600 hover:underline text-sm font-medium">View Details</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {selectedOrder && <OrderDetailModal order={selectedOrder} onClose={() => setSelectedOrder(null)} />}
        </div>
    );
};

export default OrderManagement;
