import React from 'react';
import { User } from '../../App';

interface UserManagementProps {
    users: User[];
    onDeleteUser: (userId: number) => void;
}

const UserManagement: React.FC<UserManagementProps> = ({ users, onDeleteUser }) => {
    return (
        <div>
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-3xl font-bold text-gray-800">Customer User Management</h1>
            </div>
            <div className="bg-white shadow-md rounded-lg overflow-x-auto">
                <table className="w-full min-w-max text-left">
                    <thead className="bg-gray-100">
                        <tr>
                            <th className="p-4 font-semibold">User ID</th>
                            <th className="p-4 font-semibold">Email Address</th>
                            <th className="p-4 font-semibold">Date Registered</th>
                            <th className="p-4 font-semibold">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {users.length > 0 ? (
                            users.map(user => (
                                <tr key={user.id} className="border-b hover:bg-gray-50">
                                    <td className="p-4 font-mono text-xs text-gray-600">{user.id}</td>
                                    <td className="p-4 font-medium text-gray-800">{user.email}</td>
                                    <td className="p-4 text-gray-600">
                                        {new Date(user.createdAt).toLocaleDateString('en-US', {
                                            year: 'numeric', month: 'long', day: 'numeric'
                                        })}
                                    </td>
                                    <td className="p-4">
                                        <button 
                                            onClick={() => onDeleteUser(user.id)} 
                                            className="text-red-600 hover:underline"
                                        >
                                            Delete
                                        </button>
                                    </td>
                                </tr>
                            ))
                        ) : (
                            <tr>
                                <td colSpan={4} className="text-center p-8 text-gray-500">
                                    No users have registered yet.
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
             <div className="mt-8 bg-blue-50 border-l-4 border-blue-500 text-blue-800 p-4 rounded-lg" role="alert">
                <p className="font-bold">Login Page Customization</p>
                <p>Customizing the login page appearance and settings will be available in a future update. This requires backend infrastructure to manage settings dynamically.</p>
            </div>
        </div>
    );
};

export default UserManagement;