
import React, { useState } from 'react';
import { GoogleGenAI } from '@google/genai';
import EmailPreviewModal from './EmailPreviewModal';
import { SupportTicket } from '../../App';


const StatusBadge: React.FC<{ status: SupportTicket['status'] }> = ({ status }) => {
    const baseClasses = "text-xs font-semibold px-2.5 py-1 rounded-full";
    const statusClasses = {
        Open: "bg-red-100 text-red-800",
        Resolved: "bg-green-100 text-green-800",
        Pending: "bg-yellow-100 text-yellow-800",
    };
    return <span className={`${baseClasses} ${statusClasses[status]}`}>{status}</span>;
};


const TicketDetailModal: React.FC<{ ticket: SupportTicket; onClose: () => void; onStatusChange: (id: string, status: SupportTicket['status']) => void }> = ({ ticket, onClose, onStatusChange }) => {
    const [isReplying, setIsReplying] = useState(false);
    const [replyText, setReplyText] = useState('');
    const [isAiLoading, setIsAiLoading] = useState(false);
    const [attachment, setAttachment] = useState<File | null>(null);
    const [isPreviewing, setIsPreviewing] = useState(false);

    const handleGenerateReply = async () => {
        setIsAiLoading(true);
        setReplyText('Generating AI response...');
        try {
            if (!process.env.API_KEY) {
                throw new Error("API_KEY is not configured.");
            }
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const prompt = `You are a helpful and friendly customer support agent for "Digital Catalyst", an e-commerce store selling digital products and courses. A customer named "${ticket.customerName}" has a support request with the subject "${ticket.subject}".\n\nTheir message is:\n"${ticket.message}"\n\nPlease write a professional, empathetic, and helpful reply to them. Keep it concise and address their issue directly. Sign off as "The Digital Catalyst Team".`;

            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: prompt,
            });

            setReplyText(response.text);

        } catch (err) {
            console.error("Gemini API Error:", err);
            setReplyText("Sorry, I couldn't generate a reply. Please write one manually.");
        } finally {
            setIsAiLoading(false);
        }
    };
    
    const handleSendReply = () => {
        if (!replyText.trim()) {
            alert("Reply cannot be empty.");
            return;
        }
        setIsPreviewing(true); // Open the preview modal
    };
    
    const handleConfirmSend = () => {
        // This is where a real backend would send the email.
        // We will simulate it with a mailto link, which cannot handle attachments or rich HTML.
        const body = encodeURIComponent(replyText + "\n\nNote: This is a simplified email. Attachments must be sent separately in a real application.");
        const mailtoLink = `mailto:${ticket.customerEmail}?subject=Re: ${ticket.subject}&body=${body}`;
        window.open(mailtoLink, '_blank');
        
        onStatusChange(ticket.id, 'Resolved');
        setIsPreviewing(false);
        onClose();
    };

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        if (event.target.files && event.target.files.length > 0) {
            setAttachment(event.target.files[0]);
        }
    };


    return (
        <>
        <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex justify-center items-center p-4 animate-fade-in">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto animate-scale-in-up">
                <div className="p-6 border-b flex justify-between items-center">
                    <h2 className="text-xl font-bold text-gray-800">Ticket Details: <span className="font-mono text-red-600">{ticket.id}</span></h2>
                    <button onClick={onClose} className="text-gray-400 hover:text-gray-600 font-bold text-2xl">&times;</button>
                </div>
                <div className="p-6">
                    <div className="flex justify-between items-start mb-4">
                        <div>
                            <p className="font-bold text-lg text-gray-800">{ticket.subject}</p>
                            <p className="text-sm text-gray-500">From: {ticket.customerName} ({ticket.customerEmail})</p>
                        </div>
                        <StatusBadge status={ticket.status} />
                    </div>
                    <div className="mt-4 p-4 bg-gray-50 border rounded-md">
                        <p className="text-gray-700 whitespace-pre-wrap">{ticket.message}</p>
                    </div>
                    
                    {isReplying && (
                        <div className="mt-4 pt-4 border-t">
                            <div className="flex justify-between items-center mb-2">
                                <h3 className="font-bold text-gray-800">Compose Reply</h3>
                                <button 
                                    onClick={handleGenerateReply} 
                                    disabled={isAiLoading}
                                    className="flex items-center gap-2 text-sm font-semibold bg-indigo-100 text-indigo-700 px-3 py-1.5 rounded-md hover:bg-indigo-200 transition-colors disabled:bg-gray-200 disabled:text-gray-500"
                                >
                                    {isAiLoading ? (
                                        <div className="w-4 h-4 border-2 border-indigo-700 border-t-transparent rounded-full animate-spin"></div>
                                    ) : (
                                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" /></svg>
                                    )}
                                    {isAiLoading ? 'Generating...' : '✨ Generate with AI'}
                                </button>
                            </div>
                            <textarea 
                                rows={8}
                                className="w-full p-2 border rounded-md bg-gray-50 text-sm focus:ring-2 focus:ring-blue-400"
                                value={replyText}
                                onChange={e => setReplyText(e.target.value)}
                                placeholder="Write your reply here..."
                            />
                             <div className="mt-3">
                                <label htmlFor="file-attachment" className="text-sm font-medium text-gray-700 hover:text-blue-600 cursor-pointer flex items-center gap-2">
                                     <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                                        <path fillRule="evenodd" d="M8 4a3 3 0 00-3 3v4a3 3 0 006 0V7a1 1 0 112 0v4a5 5 0 01-10 0V7a5 5 0 0110 0v4a1 1 0 11-2 0V7a3 3 0 00-3-3z" clipRule="evenodd" />
                                     </svg>
                                     Attach File
                                </label>
                                <input id="file-attachment" type="file" className="hidden" onChange={handleFileChange} />
                                {attachment && (
                                    <div className="mt-2 text-xs bg-gray-100 p-2 rounded flex justify-between items-center">
                                        <span className="text-gray-600 font-medium truncate pr-2">{attachment.name}</span>
                                        <button onClick={() => setAttachment(null)} className="text-red-500 font-bold text-lg">&times;</button>
                                    </div>
                                )}
                            </div>
                        </div>
                    )}
                </div>

                <div className="p-6 bg-gray-50 border-t flex justify-end space-x-3">
                    {isReplying ? (
                        <>
                            <button onClick={() => setIsReplying(false)} className="px-5 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300">Cancel</button>
                            <button onClick={handleSendReply} className="px-5 py-2 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700">Send Reply</button>
                        </>
                    ) : (
                        <>
                            <button onClick={onClose} className="px-5 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300">Close</button>
                            <button onClick={() => setIsReplying(true)} className="px-5 py-2 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700">Reply</button>
                            {ticket.status !== 'Resolved' && (
                                <button onClick={() => { onStatusChange(ticket.id, 'Resolved'); onClose(); }} className="px-5 py-2 bg-green-500 text-white font-semibold rounded-lg hover:bg-green-600">Mark as Resolved</button>
                            )}
                        </>
                    )}
                </div>
            </div>
        </div>
        
        {isPreviewing && (
             <EmailPreviewModal 
                ticket={ticket}
                replyText={replyText}
                attachment={attachment}
                onClose={() => setIsPreviewing(false)}
                onConfirmSend={handleConfirmSend}
            />
        )}
        </>
    );
};


const SupportManagement: React.FC<{
    tickets: SupportTicket[];
    onUpdate: (updatedTickets: SupportTicket[]) => void;
}> = ({ tickets, onUpdate }) => {
    const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(null);

    const handleStatusChange = (id: string, status: SupportTicket['status']) => {
        const updatedTickets = tickets.map(t => t.id === id ? { ...t, status } : t);
        onUpdate(updatedTickets);
    };

    return (
        <div>
            <h1 className="text-3xl font-bold text-gray-800 mb-6">Support Ticket Management</h1>

            <div className="mb-6 bg-blue-50 border-l-4 border-blue-500 text-blue-800 p-4 rounded-r-lg" role="alert">
                <p className="font-bold">Live Data</p>
                <p className="text-sm">This component now displays and manages live support ticket data from the main application state. Changes will be persisted in local storage.</p>
            </div>

            <div className="bg-white shadow-md rounded-lg overflow-x-auto">
                 <table className="w-full min-w-max text-left">
                    <thead className="bg-gray-100">
                        <tr>
                            <th className="p-4 font-semibold">Ticket ID</th>
                            <th className="p-4 font-semibold">Customer</th>
                            <th className="p-4 font-semibold">Subject</th>
                            <th className="p-4 font-semibold">Date</th>
                            <th className="p-4 font-semibold">Status</th>
                            <th className="p-4 font-semibold">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {tickets.map(ticket => (
                            <tr key={ticket.id} className="border-b hover:bg-gray-50">
                                <td className="p-4 font-mono text-xs font-medium text-red-600">{ticket.id}</td>
                                <td className="p-4">
                                    <p className="font-medium text-gray-800 text-sm">{ticket.customerName}</p>
                                    <p className="text-xs text-gray-500">{ticket.customerEmail}</p>
                                </td>
                                <td className="p-4 text-sm font-medium text-gray-700">{ticket.subject}</td>
                                <td className="p-4 text-sm text-gray-600">
                                    {new Date(ticket.date).toLocaleString()}
                                </td>
                                <td className="p-4">
                                    <StatusBadge status={ticket.status} />
                                </td>
                                <td className="p-4">
                                    <button onClick={() => setSelectedTicket(ticket)} className="text-blue-600 hover:underline text-sm font-medium">View Details</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            {selectedTicket && <TicketDetailModal key={selectedTicket.id} ticket={selectedTicket} onClose={() => setSelectedTicket(null)} onStatusChange={handleStatusChange} />}
        </div>
    );
};

export default SupportManagement;