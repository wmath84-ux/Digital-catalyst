import React, { useState } from 'react';
import { Product, ProductWithRating, Review, User, Coupon, WebsiteSettings, Order, AdminUser, SupportTicket } from '../../App';
import Sidebar from './Sidebar';
import ProductManagement from './ProductManagement';
import UserManagement from './UserManagement';
import OrderManagement from './OrderManagement';
import CouponManagement from './CouponManagement';
import SupportManagement from './SupportManagement';
import Analytics from './Analytics';
import AdminReviewManagement from './AdminReviewManagement';
import Reports from './Reports';
import GeminiAssistant from './GeminiAssistant';
import WebsiteSettingsComponent from './WebsiteSettings';
import AdminManagement from './AdminManagement';


interface AdminDashboardProps {
    products: ProductWithRating[];
    reviews: { [productId: number]: Review[] };
    users: User[];
    adminUsers: AdminUser[];
    currentAdminUser: AdminUser;
    coupons: Coupon[];
    orders: Order[];
    tickets: SupportTicket[];
    websiteSettings: WebsiteSettings;
    onAddProduct: (product: Omit<Product, 'id'>) => void;
    onUpdateProduct: (product: Product) => void;
    onDeleteProduct: (id: number) => void;
    onDeleteUser: (id: number) => void;
    onAdminUsersUpdate: (users: AdminUser[]) => void;
    onCouponsUpdate: (coupons: Coupon[]) => void;
    onTicketsUpdate: (tickets: SupportTicket[]) => void;
    onWebsiteSettingsChange: (settings: WebsiteSettings) => void;
    onLogout: () => void;
}

export type AdminView = 'dashboard' | 'products' | 'reviews' | 'reports' | 'users' | 'admins' | 'orders' | 'coupons' | 'support' | 'analytics' | 'gemini' | 'websiteSettings';

const AdminDashboard: React.FC<AdminDashboardProps> = (props) => {
    const [currentView, setCurrentView] = useState<AdminView>('dashboard');

    const renderView = () => {
        switch (currentView) {
            case 'products': return <ProductManagement products={props.products} users={props.users} coupons={props.coupons} onAddProduct={props.onAddProduct} onUpdateProduct={props.onUpdateProduct} onDeleteProduct={props.onDeleteProduct} />;
            case 'reviews': return <AdminReviewManagement products={props.products} reviews={props.reviews} />;
            case 'reports': return <Reports products={props.products} reviews={props.reviews} />;
            case 'users': return <UserManagement users={props.users} onDeleteUser={props.onDeleteUser} />;
            case 'admins': return <AdminManagement adminUsers={props.adminUsers} currentAdminUser={props.currentAdminUser} onUpdateAdminUsers={props.onAdminUsersUpdate} />;
            case 'orders': return <OrderManagement orders={props.orders} />;
            case 'coupons': return <CouponManagement coupons={props.coupons} onUpdate={props.onCouponsUpdate} />;
            case 'support': return <SupportManagement tickets={props.tickets} onUpdate={props.onTicketsUpdate} />;
            case 'analytics': return <Analytics orders={props.orders} products={props.products} users={props.users} />;
            case 'gemini': return <GeminiAssistant />;
            case 'websiteSettings': return <WebsiteSettingsComponent settings={props.websiteSettings} onSettingsChange={props.onWebsiteSettingsChange} />;
            case 'dashboard': default: 
                const completedOrders = props.orders.filter(o => o.status === 'Completed');
                const totalRevenue = completedOrders.reduce((sum, order) => sum + parseFloat(order.total.replace('₹', '')), 0);
                return (
                    <div>
                        <h1 className="text-3xl font-bold text-gray-800">Welcome, {props.currentAdminUser.email.split('@')[0]}!</h1>
                        <p className="mt-2 text-gray-600">You are logged in as a <span className="font-semibold text-primary">{props.currentAdminUser.role}</span>. Select a section to get started.</p>
                        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                            <div className="bg-white p-6 rounded-lg shadow-md">
                                <h3 className="font-bold text-lg text-primary">Total Revenue</h3>
                                <p className="text-3xl font-bold mt-2">₹{totalRevenue.toLocaleString('en-IN')}</p>
                            </div>
                            <div className="bg-white p-6 rounded-lg shadow-md">
                                <h3 className="font-bold text-lg text-primary">Total Products</h3>
                                <p className="text-3xl font-bold mt-2">{props.products.length}</p>
                            </div>
                            <div className="bg-white p-6 rounded-lg shadow-md">
                                <h3 className="font-bold text-lg text-primary">Total Users</h3>
                                <p className="text-3xl font-bold mt-2">{props.users.length}</p>
                            </div>
                            <div className="bg-white p-6 rounded-lg shadow-md">
                                <h3 className="font-bold text-lg text-primary">Total Reviews</h3>
                                <p className="text-3xl font-bold mt-2">{Object.values(props.reviews).flat().length}</p>
                            </div>
                        </div>
                    </div>
                );
        }
    }

    return (
        <div className="flex min-h-screen bg-gray-100">
            <Sidebar onNavigate={setCurrentView} onLogout={props.onLogout} currentView={currentView} />
            <main className="flex-1 p-6 sm:p-8 lg:p-10">
                {renderView()}
            </main>
        </div>
    );
};

export default AdminDashboard;