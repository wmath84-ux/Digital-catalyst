import React, { useState } from 'react';
import { Order, ProductWithRating, User } from '../../App';

const StatCard: React.FC<{ title: string; value: string | number; change?: string; changeType?: 'increase' | 'decrease' }> = ({ title, value, change, changeType }) => {
    const changeColor = changeType === 'increase' ? 'text-green-600' : 'text-red-500';
    const arrow = changeType === 'increase' ? '↑' : '↓';

    return (
        <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
            <h3 className="text-sm font-medium text-gray-500">{title}</h3>
            <div className="mt-2 flex items-baseline justify-between">
                <p className="text-3xl font-bold text-gray-800">{value}</p>
                {change && (
                    <span className={`text-sm font-semibold ${changeColor}`}>
                        {arrow} {change}
                    </span>
                )}
            </div>
        </div>
    );
};

interface AnalyticsProps {
    orders: Order[];
    products: ProductWithRating[];
    users: User[];
}

type DateRange = 'today' | '7d' | '30d' | 'all';

const Analytics: React.FC<AnalyticsProps> = ({ orders, products, users }) => {
    const [dateRange, setDateRange] = useState<DateRange>('all');

    // --- Filtering Logic ---
    const getFilteredData = () => {
        if (dateRange === 'all') {
            return { filteredOrders: orders, filteredUsers: users };
        }

        const today = new Date();
        const todayEnd = new Date();
        today.setHours(0, 0, 0, 0);
        todayEnd.setHours(23, 59, 59, 999);

        if (dateRange === 'today') {
            const todayStr = today.toISOString().split('T')[0];
            const filteredOrders = orders.filter(o => o.date === todayStr);
            const filteredUsers = users.filter(u => {
                try {
                    return new Date(u.createdAt).toISOString().split('T')[0] === todayStr;
                } catch (e) { return false; }
            });
            return { filteredOrders, filteredUsers };
        }

        const pastDate = new Date(today);
        if (dateRange === '7d') {
            pastDate.setDate(today.getDate() - 7);
        } else if (dateRange === '30d') {
            pastDate.setDate(today.getDate() - 30);
        }

        const filteredOrders = orders.filter(o => {
            try {
                const orderDate = new Date(o.date);
                return orderDate >= pastDate && orderDate <= todayEnd;
            } catch (e) { return false; }
        });

        const filteredUsers = users.filter(u => {
            try {
                const userDate = new Date(u.createdAt);
                return userDate >= pastDate && userDate <= todayEnd;
            } catch (e) { return false; }
        });

        return { filteredOrders, filteredUsers };
    };

    const { filteredOrders, filteredUsers: newUsersInPeriod } = getFilteredData();

    // --- Data Calculations ---
    const completedOrders = filteredOrders.filter(o => o.status === 'Completed');
    const totalRevenue = completedOrders.reduce((sum, order) => sum + parseFloat(order.total.replace('₹', '').replace(/,/g, '') || '0'), 0);
    
    const uniqueCustomersInPeriod = new Set(completedOrders.map(o => o.customerEmail));
    const totalCustomersCount = uniqueCustomersInPeriod.size;

    const averageOrderValue = completedOrders.length > 0 ? totalRevenue / completedOrders.length : 0;
    
    const newUsersWhoPurchased = newUsersInPeriod.filter(u => uniqueCustomersInPeriod.has(u.email));
    const conversionRate = newUsersInPeriod.length > 0 ? (newUsersWhoPurchased.length / newUsersInPeriod.length) * 100 : 0;
    
    const productSales = new Map<number, { name: string; quantity: number }>();
    completedOrders.forEach(order => {
        order.items.forEach(item => {
            const productInfo = products.find(p => p.id === item.id);
            if (!productInfo) return; 

            const existing = productSales.get(item.id);
            if (existing) {
                existing.quantity += item.quantity;
            } else {
                productSales.set(item.id, { name: productInfo.title, quantity: item.quantity });
            }
        });
    });
    const topSellingProducts = Array.from(productSales.values()).sort((a, b) => b.quantity - a.quantity).slice(0, 5);
    
    const DateFilterButtons = () => {
        const ranges: {label: string, value: DateRange}[] = [
            { label: 'Today', value: 'today'},
            { label: 'Last 7 Days', value: '7d'},
            { label: 'Last 30 Days', value: '30d'},
            { label: 'All Time', value: 'all'},
        ];
        return (
             <div className="flex space-x-2 mb-6">
                {ranges.map(range => (
                    <button
                        key={range.value}
                        onClick={() => setDateRange(range.value)}
                        className={`px-4 py-2 text-sm font-semibold rounded-lg transition-colors ${
                            dateRange === range.value
                                ? 'bg-primary text-white shadow'
                                : 'bg-white text-gray-600 hover:bg-gray-100 border'
                        }`}
                    >
                        {range.label}
                    </button>
                ))}
            </div>
        );
    };

    return (
        <div>
            <h1 className="text-3xl font-bold text-gray-800 mb-2">Store Analytics</h1>
            <p className="text-gray-500 mb-6">View key metrics for different time periods.</p>
            
            <DateFilterButtons />

            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <StatCard title="Total Revenue" value={`₹${totalRevenue.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`} />
                <StatCard title="Completed Orders" value={completedOrders.length.toLocaleString('en-IN')} />
                <StatCard title="New Customers" value={totalCustomersCount.toLocaleString('en-IN')} />
                <StatCard title="New Users" value={newUsersInPeriod.length.toLocaleString('en-IN')} />
                <StatCard title="Avg. Order Value" value={`₹${averageOrderValue.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`} />
                <StatCard title="New User Conversion" value={`${conversionRate.toFixed(2)}%`} />
            </div>

            {/* Charts and Lists */}
            <div className="mt-8 grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Sales Chart */}
                <div className="lg:col-span-2 bg-white p-6 rounded-lg shadow-md border">
                    <h3 className="font-bold text-lg text-gray-800 mb-4">Sales Over Time</h3>
                    <div className="h-80 bg-gray-100 rounded-md flex items-center justify-center">
                        <p className="text-gray-500 text-center px-4">[Sales Chart Placeholder]<br/><span className="text-sm">This would dynamically show sales data for the selected date range.</span></p>
                    </div>
                </div>

                {/* Top Products */}
                <div className="bg-white p-6 rounded-lg shadow-md border">
                    <h3 className="font-bold text-lg text-gray-800 mb-4">Top Selling Products</h3>
                    {topSellingProducts.length > 0 ? (
                        <ul className="space-y-3">
                            {topSellingProducts.map((product, index) => (
                                <li key={product.name} className="flex justify-between text-sm">
                                    <span className="font-medium text-gray-700 truncate pr-4">{index + 1}. {product.name}</span> 
                                    <span className="font-bold flex-shrink-0">{product.quantity} units</span>
                                </li>
                            ))}
                        </ul>
                    ) : (
                        <p className="text-sm text-center text-gray-500 pt-8">No completed sales data available for this period.</p>
                    )}
                </div>
            </div>
        </div>
    );
};

export default Analytics;