

import React from 'react';
import { AdminView } from './AdminDashboard';

interface SidebarProps {
    currentView: AdminView;
    onNavigate: (view: AdminView) => void;
    onLogout: () => void;
}

const NavLink: React.FC<{
    label: string;
    view: AdminView;
    currentView: AdminView;
    onClick: (view: AdminView) => void;
    isFeatured?: boolean;
}> = ({ label, view, currentView, onClick, isFeatured }) => (
    <button
        onClick={() => onClick(view)}
        className={`w-full text-left px-4 py-2.5 rounded-lg transition-colors flex items-center justify-between ${
            currentView === view
                ? 'bg-primary text-white shadow'
                : 'text-gray-200 hover:bg-accent/50 hover:text-white'
        }`}
    >
        {label}
        {isFeatured && <span className="text-xs bg-yellow-400 text-yellow-900 font-bold px-2 py-0.5 rounded-full">AI</span>}
    </button>
);

const Sidebar: React.FC<SidebarProps> = ({ currentView, onNavigate, onLogout }) => {
    const navItems: { label: string; view: AdminView, isFeatured?: boolean }[] = [
        { label: 'Dashboard', view: 'dashboard' },
        { label: 'Site Customizer', view: 'websiteSettings' },
        { label: 'Products', view: 'products' },
        { label: 'Reviews', view: 'reviews' },
        { label: 'Reports', view: 'reports' },
        { label: 'AI Assistant', view: 'gemini', isFeatured: true },
        { label: 'Customer Users', view: 'users' },
        { label: 'Admin Users', view: 'admins' },
        { label: 'Orders', view: 'orders' },
        { label: 'Coupons', view: 'coupons' },
        { label: 'Support', view: 'support' },
        { label: 'Analytics', view: 'analytics' },
    ];

    return (
        <aside className="w-64 bg-primary text-white flex flex-col p-4">
            <div className="text-2xl font-bold mb-8 px-2">Admin Panel</div>
            <nav className="flex-1 space-y-2">
                {navItems.map(item => (
                    <NavLink
                        key={item.view}
                        label={item.label}
                        view={item.view}
                        currentView={currentView}
                        onClick={onNavigate}
                        isFeatured={item.isFeatured}
                    />
                ))}
            </nav>
            <div>
                <button
                    onClick={onLogout}
                    className="w-full text-left px-4 py-2.5 rounded-lg transition-colors text-gray-200 hover:bg-red-500 hover:text-white"
                >
                    Logout
                </button>
            </div>
        </aside>
    );
};

export default Sidebar;