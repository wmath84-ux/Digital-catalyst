import React, { useState } from 'react';
import { Coupon } from '../../App';


const CouponFormModal: React.FC<{ coupon?: Coupon | null; onSave: (coupon: Omit<Coupon, 'id' | 'timesUsed'>) => void; onClose: () => void }> = ({ coupon, onSave, onClose }) => {
    const [formData, setFormData] = useState({
        code: coupon?.code || '',
        type: coupon?.type || 'percentage',
        value: coupon?.value || 0,
        expiryDate: coupon?.expiryDate || '',
        isActive: coupon?.isActive === undefined ? true : coupon.isActive,
        usageLimit: coupon?.usageLimit || 100,
    });

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value, type } = e.target;
        if (type === 'checkbox') {
            setFormData(prev => ({ ...prev, [name]: (e.target as HTMLInputElement).checked }));
        } else {
            setFormData(prev => ({ ...prev, [name]: value }));
        }
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({
            ...formData,
            value: Number(formData.value),
            usageLimit: Number(formData.usageLimit),
        });
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex justify-center items-center p-4 animate-fade-in">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-md animate-scale-in-up">
                <form onSubmit={handleSubmit}>
                    <div className="p-6 border-b">
                        <h2 className="text-xl font-bold text-gray-800">{coupon ? 'Edit Coupon' : 'Create New Coupon'}</h2>
                    </div>
                    <div className="p-6 space-y-4">
                        <input name="code" value={formData.code} onChange={handleChange} placeholder="Coupon Code (e.g., NEWYEAR20)" required className="w-full p-2 border rounded" />
                        <div className="grid grid-cols-2 gap-4">
                            <select name="type" value={formData.type} onChange={handleChange} className="w-full p-2 border rounded">
                                <option value="percentage">Percentage (%)</option>
                                <option value="fixed">Fixed Amount (₹)</option>
                            </select>
                            <input name="value" type="number" value={formData.value} onChange={handleChange} placeholder="Value" required className="w-full p-2 border rounded" />
                        </div>
                        <input name="expiryDate" type="date" value={formData.expiryDate} onChange={handleChange} required className="w-full p-2 border rounded" />
                        <input name="usageLimit" type="number" value={formData.usageLimit} onChange={handleChange} placeholder="Usage Limit" required className="w-full p-2 border rounded" />
                         <label className="flex items-center space-x-3">
                             <input type="checkbox" name="isActive" checked={formData.isActive} onChange={handleChange} className="form-checkbox h-5 w-5 text-blue-600"/>
                             <span className="text-gray-700">Activate Coupon</span>
                         </label>
                    </div>
                    <div className="p-6 bg-gray-50 border-t flex justify-end space-x-3">
                        <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 rounded-lg hover:bg-gray-300">Cancel</button>
                        <button type="submit" className="px-6 py-2 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-700">Save</button>
                    </div>
                </form>
            </div>
        </div>
    );
};

interface CouponManagementProps {
    coupons: Coupon[];
    onUpdate: (updatedCoupons: Coupon[]) => void;
}


const CouponManagement: React.FC<CouponManagementProps> = ({ coupons, onUpdate }) => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingCoupon, setEditingCoupon] = useState<Coupon | null>(null);

    const handleOpenModal = (coupon?: Coupon) => {
        setEditingCoupon(coupon || null);
        setIsModalOpen(true);
    };

    const handleSave = (couponData: Omit<Coupon, 'id' | 'timesUsed'>) => {
        if (editingCoupon) {
            onUpdate(coupons.map(c => c.id === editingCoupon.id ? { ...editingCoupon, ...couponData } : c));
        } else {
            const newCoupon: Coupon = { ...couponData, id: Date.now(), timesUsed: 0 };
            onUpdate([newCoupon, ...coupons]);
        }
        setIsModalOpen(false);
    };

    const handleDelete = (id: number) => {
        if (window.confirm('Are you sure you want to delete this coupon?')) {
            onUpdate(coupons.filter(c => c.id !== id));
        }
    };
    
    const handleToggleStatus = (id: number) => {
        onUpdate(coupons.map(c => c.id === id ? { ...c, isActive: !c.isActive } : c));
    };

    return (
        <div>
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-3xl font-bold text-gray-800">Coupon Management</h1>
                <button onClick={() => handleOpenModal()} className="bg-blue-600 text-white font-semibold px-5 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                    + Create New Coupon
                </button>
            </div>
            
            <div className="mb-6 bg-blue-50 border-l-4 border-blue-500 text-blue-800 p-4 rounded-r-lg" role="alert">
                <p className="font-bold">Demonstration Page</p>
                <p className="text-sm">This is an interactive demo. Changes are not saved permanently. A backend is required to manage coupons for a live store.</p>
            </div>

            <div className="bg-white shadow-md rounded-lg overflow-x-auto">
                <table className="w-full min-w-max text-left">
                    <thead className="bg-gray-100">
                        <tr>
                            <th className="p-4 font-semibold">Code</th>
                            <th className="p-4 font-semibold">Discount</th>
                            <th className="p-4 font-semibold">Usage</th>
                            <th className="p-4 font-semibold">Expiry Date</th>
                            <th className="p-4 font-semibold">Status</th>
                            <th className="p-4 font-semibold">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {coupons.map(coupon => (
                            <tr key={coupon.id} className="border-b hover:bg-gray-50">
                                <td className="p-4 font-mono text-sm font-medium text-purple-700">{coupon.code}</td>
                                <td className="p-4 text-sm">{coupon.type === 'percentage' ? `${coupon.value}%` : `₹${coupon.value}`}</td>
                                <td className="p-4 text-sm">{coupon.timesUsed} / {coupon.usageLimit}</td>
                                <td className="p-4 text-sm">{new Date(coupon.expiryDate).toLocaleDateString()}</td>
                                <td className="p-4">
                                     <label className="relative inline-flex items-center cursor-pointer">
                                        <input type="checkbox" checked={coupon.isActive} onChange={() => handleToggleStatus(coupon.id)} className="sr-only peer" />
                                        <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
                                    </label>
                                </td>
                                <td className="p-4 space-x-3">
                                    <button onClick={() => handleOpenModal(coupon)} className="text-blue-600 hover:underline text-sm font-medium">Edit</button>
                                    <button onClick={() => handleDelete(coupon.id)} className="text-red-600 hover:underline text-sm font-medium">Delete</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            {isModalOpen && <CouponFormModal coupon={editingCoupon} onSave={handleSave} onClose={() => setIsModalOpen(false)} />}
        </div>
    );
};

export default CouponManagement;