import React, { useState, useEffect, useRef } from 'react';
import { ProductWithRating, WebsiteSettings } from '../App';

const PurchasedProductCard: React.FC<{
  settings: WebsiteSettings;
  product: ProductWithRating;
  onViewProduct: () => void;
}> = ({ settings, product, onViewProduct }) => {
    const animationClass = settings.animations.enabled ? 'animate-fade-in-up' : '';
    const buttonText = product.category === 'E-books' ? 'Start Reading' : 'Start Course';

    return (
        <div className={`relative bg-white rounded-xl shadow-lg overflow-hidden border border-gray-100 flex flex-col transform hover:-translate-y-2 transition-all duration-300 ease-in-out hover:shadow-xl product-card-shine ${animationClass}`}>
            <img src={product.images[0] || `https://picsum.photos/seed/${product.imageSeed}/600/400`} alt={product.title} className="w-full h-48 object-cover" />
            <div className="p-6 flex flex-col flex-grow">
            <h3 className="text-xl font-bold text-primary">{product.title}</h3>
            <p className="mt-2 text-text-muted text-sm flex-grow">{product.description}</p>
            <div className="mt-4">
                <button onClick={onViewProduct} className="w-full bg-primary text-white font-semibold px-5 py-2.5 rounded-lg hover:opacity-90 transition-all duration-300 transform active:scale-95">
                {buttonText}
                </button>
            </div>
            </div>
        </div>
    );
};


interface PurchasedProductsProps {
  settings: WebsiteSettings;
  products: ProductWithRating[];
  onViewPurchasedProduct: (product: ProductWithRating) => void;
}

const PurchasedProducts: React.FC<PurchasedProductsProps> = ({ settings, products, onViewPurchasedProduct }) => {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
        (entries) => {
            const [entry] = entries;
            entry.target.classList.toggle('is-visible', entry.isIntersecting);
        },
        { threshold: 0.05 }
    );

    const currentRef = sectionRef.current;
    if (currentRef) {
        observer.observe(currentRef);
    }

    return () => {
        if (currentRef) {
            observer.unobserve(currentRef);
        }
    };
  }, []);

  return (
    <section 
      ref={sectionRef}
      className={`py-20 sm:py-24 ${settings.animations.enabled ? 'scroll-animate' : ''}`}
    >
      <div className="container mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto">
          <h2 className="text-3xl sm:text-4xl font-extrabold text-primary">My Purchases</h2>
          <p className="mt-4 text-lg text-text-muted">
            Welcome back! Here are the products you have access to.
          </p>
        </div>
        <div className="mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
          {products.map((product) => (
            <PurchasedProductCard 
              key={product.id} 
              settings={settings}
              product={product} 
              onViewProduct={() => onViewPurchasedProduct(product)}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default PurchasedProducts;