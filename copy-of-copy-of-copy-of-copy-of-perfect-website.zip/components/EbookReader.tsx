

import React, { useState, useEffect, useRef } from 'react';
import { ProductWithRating, CourseModule, ProductFile, WebsiteSettings } from '../App';
import AiMentor from './AiMentor';
import { GoogleGenAI } from '@google/genai';

// --- TYPES ---
type Theme = 'light' | 'sepia' | 'dark' | 'slate' | 'green';
interface Note {
  id: string;
  quote: string;
  text: string;
  highlightId: string;
}

// --- SUB-COMPONENTS ---

const SettingsPanel: React.FC<{
    theme: Theme;
    onThemeChange: (theme: Theme) => void;
    fontSize: number;
    onFontSizeChange: (size: number) => void;
    fontFamily: string;
    onFontFamilyChange: (family: string) => void;
}> = ({ theme, onThemeChange, fontSize, onFontSizeChange, fontFamily, onFontFamilyChange }) => {
    const themes: { name: Theme; bg: string; border: string; label: string }[] = [
        { name: 'light', bg: '#ffffff', border: '#e2e8f0', label: 'Light' },
        { name: 'sepia', bg: '#fbf5e9', border: '#e3d5b8', label: 'Sepia' },
        { name: 'dark', bg: '#1a202c', border: '#4a5568', label: 'Dark' },
        { name: 'slate', bg: '#1e293b', border: '#475569', label: 'Slate' },
        { name: 'green', bg: '#f0fdf4', border: '#bbf7d0', label: 'Green' },
    ];
    
    return (
        <div className="absolute top-full right-4 mt-2 bg-white dark:bg-slate-800 shadow-lg rounded-lg p-6 z-20 w-80 border border-gray-200 dark:border-slate-600 animate-fade-in-up">
            <h4 className="font-bold text-center text-gray-800 dark:text-gray-200 mb-6">Display Settings</h4>
            
            <div className="mb-6">
                <p className="text-sm font-semibold text-gray-600 dark:text-gray-300 mb-2">Theme</p>
                <div className="grid grid-cols-5 gap-2">
                    {themes.map(t => (
                        <button key={t.name} onClick={() => onThemeChange(t.name)} className={`py-1 rounded-md border-2 transition-all ${theme === t.name ? 'border-primary ring-2 ring-primary/30' : 'border-gray-300 dark:border-gray-600'}`}>
                            <div className="w-8 h-8 border rounded-full mx-auto" style={{ backgroundColor: t.bg, borderColor: t.border }}></div>
                        </button>
                    ))}
                </div>
            </div>

            <div className="mb-6">
                <p className="text-sm font-semibold text-gray-600 dark:text-gray-300 mb-2">Font Size</p>
                <div className="flex items-center justify-between bg-gray-200 dark:bg-slate-700 rounded-lg p-1">
                    <button onClick={() => onFontSizeChange(Math.max(12, fontSize - 1))} className="px-4 py-1 font-bold text-xl text-gray-600 dark:text-gray-300 hover:bg-gray-300 dark:hover:bg-slate-600 rounded-md">-</button>
                    <span className="text-sm font-semibold text-gray-700 dark:text-gray-200">{fontSize}px</span>
                    <button onClick={() => onFontSizeChange(Math.min(32, fontSize + 1))} className="px-4 py-1 font-bold text-xl text-gray-600 dark:text-gray-300 hover:bg-gray-300 dark:hover:bg-slate-600 rounded-md">+</button>
                </div>
            </div>

            <div>
                <p className="text-sm font-semibold text-gray-600 dark:text-gray-300 mb-2">Font Style</p>
                 <div className="flex bg-gray-200 dark:bg-slate-700 rounded-lg p-1">
                    <button onClick={() => onFontFamilyChange('serif')} className={`w-1/2 py-1.5 rounded-md text-sm font-semibold transition-colors ${fontFamily === 'serif' ? 'bg-white dark:bg-slate-600 shadow text-primary dark:text-white' : 'text-gray-500 dark:text-gray-300'}`}>Serif</button>
                    <button onClick={() => onFontFamilyChange('sans')} className={`w-1/2 py-1.5 rounded-md text-sm font-semibold transition-colors ${fontFamily === 'sans' ? 'bg-white dark:bg-slate-600 shadow text-primary dark:text-white' : 'text-gray-500 dark:text-gray-300'}`}>Sans-Serif</button>
                </div>
            </div>
        </div>
    );
};

const ModuleItem: React.FC<{ module: CourseModule; activeFile: ProductFile | null; onSelectFile: (file: ProductFile) => void; level?: number; }> = ({ module, activeFile, onSelectFile, level = 0 }) => {
    const [isExpanded, setIsExpanded] = useState(true);
    return (
        <div className={`mt-2 ${level > 0 ? "pl-3 border-l-2 border-gray-200" : ""}`}>
            <button onClick={() => setIsExpanded(!isExpanded)} className="w-full text-left flex items-center justify-between p-2 rounded themed-hover-bg" aria-expanded={isExpanded}>
                <span className="font-bold themed-text-strong">{module.title}</span>
                <svg className={`w-5 h-5 themed-text-muted transform transition-transform ${isExpanded ? 'rotate-90' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7"></path></svg>
            </button>
            {isExpanded && <div className="pl-2 mt-1">
                {module.files.map((file) => (
                    <button
                        key={file.id}
                        onClick={() => onSelectFile(file)}
                        className={`flex items-center w-full text-left p-2 my-1 rounded text-sm transition-colors ${activeFile?.id === file.id ? "bg-blue-100 text-primary font-semibold" : "themed-hover-bg themed-text"}`}
                    >
                         <div className="flex items-center gap-2 w-full">
                             {file.type === 'ebook' ? (
                                <svg className="w-4 h-4 themed-text-muted flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path></svg>
                             ) : (
                                <svg className="w-4 h-4 themed-text-muted flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
                             )}
                             <span className="truncate">{file.name}</span>
                        </div>
                    </button>
                ))}
                {module.modules.map((subModule) => <ModuleItem key={subModule.id} module={subModule} activeFile={activeFile} onSelectFile={onSelectFile} level={level + 1} />)}
            </div>}
        </div>
    );
};

const EbookReader: React.FC<{
    settings: WebsiteSettings;
    product: ProductWithRating;
    onBack: () => void;
}> = ({ settings, product, onBack }) => {
    const [activeFile, setActiveFile] = useState<ProductFile | null>(null);
    const [isSidebarOpen, setIsSidebarOpen] = useState(false);
    const [ebookPanelHeight, setEbookPanelHeight] = useState(60);
    const contentRef = useRef<HTMLDivElement>(null);
    const settingsPanelRef = useRef<HTMLDivElement>(null);

    const [theme, setTheme] = useState<Theme>('light');
    const [fontSize, setFontSize] = useState(18);
    const [fontFamily, setFontFamily] = useState('serif');
    const [isSettingsPanelOpen, setIsSettingsPanelOpen] = useState(false);

    const [selectionRange, setSelectionRange] = useState<Range | null>(null);
    const [notes, setNotes] = useState<Note[]>([]);
    const [isNotesPanelOpen, setIsNotesPanelOpen] = useState(false);

    const [isTranslating, setIsTranslating] = useState(false);
    const [translationResult, setTranslationResult] = useState<{ original: string; translated: string } | null>(null);

    const isInteractive = activeFile?.type === 'ebook';
    const isPdf = activeFile?.type === 'pdf';

    useEffect(() => {
        const findFirstFile = (modules?: CourseModule[]): ProductFile | null => {
            if (!modules) return null;
            for (const m of modules) {
                if (m.files.length > 0) return m.files[0];
                const foundInSub = findFirstFile(m.modules);
                if (foundInSub) return foundInSub;
            }
            return null;
        };
        setActiveFile(findFirstFile(product.courseContent));
    }, [product]);

    useEffect(() => {
        function handleClickOutside(event: MouseEvent) {
            const target = event.target as Node;
            if (settingsPanelRef.current && !settingsPanelRef.current.contains(target)) {
                 if (!(target instanceof HTMLElement && target.closest('[aria-label="Display Settings"]'))) {
                    setIsSettingsPanelOpen(false);
                 }
            }
        }
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, [settingsPanelRef]);

    // Handles showing/hiding the text selection toolbar
    useEffect(() => {
        const contentEl = contentRef.current;
        if (!contentEl || !isInteractive) return;
    
        const handleSelectionChange = () => {
            const selection = window.getSelection();
    
            if (selection && !selection.isCollapsed && selection.rangeCount > 0) {
                const range = selection.getRangeAt(0);
                
                if (contentEl.contains(range.commonAncestorContainer)) {
                    if (range.getBoundingClientRect().width > 1 || range.getBoundingClientRect().height > 1) { // Ignore simple clicks
                        setSelectionRange(range.cloneRange());
                        return;
                    }
                }
            }
            
            // If no valid selection, hide the toolbar
            setSelectionRange(null);
        };
    
        document.addEventListener('selectionchange', handleSelectionChange);
        // A click outside the selection should clear it
        const handleMouseUp = () => {
            setTimeout(() => {
                const selection = window.getSelection();
                if (selection && selection.isCollapsed) {
                    setSelectionRange(null);
                }
            }, 10);
        };
        document.addEventListener('mouseup', handleMouseUp);
    
        return () => {
            document.removeEventListener('selectionchange', handleSelectionChange);
            document.removeEventListener('mouseup', handleMouseUp);
        };
    }, [isInteractive]);

    const performAction = (action: () => void) => {
        action();
        window.getSelection()?.removeAllRanges();
    };

    const highlightSelection = (noteStyle: boolean = false): string | undefined => {
        if (!selectionRange) return;
        try {
            const mark = document.createElement('mark');
            mark.className = noteStyle ? 'ebook-highlight-note' : 'ebook-highlight';
            const id = noteStyle ? `note-highlight-${Date.now()}` : '';
            if (id) mark.id = id;
            
            const content = selectionRange.cloneContents();
            mark.appendChild(content);
            selectionRange.deleteContents();
            selectionRange.insertNode(mark);
            return id;
        } catch (e) { console.error("Highlight failed:", e); }
        return undefined;
    };
    
    const handleHighlight = () => {
        highlightSelection(false);
    };

    const handleAddNote = () => {
        if (!selectionRange) return;
        const quote = selectionRange.toString();
        const highlightId = highlightSelection(true);
        if (!highlightId) return;

        const newNote: Note = { id: `note-${Date.now()}`, quote, text: '', highlightId };
        setNotes(prev => [newNote, ...prev]);
        setIsNotesPanelOpen(true);
    };

    const handleTranslate = async () => {
        if (!selectionRange) return;
        const textToTranslate = selectionRange.toString();
        setIsTranslating(true);
        setTranslationResult({ original: textToTranslate, translated: 'Translating...' });
        
        try {
            if (!process.env.API_KEY) throw new Error("API_KEY is not configured.");
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const prompt = `Translate the following text to English:\n\n"${textToTranslate}"`;
            const response = await ai.models.generateContent({ model: 'gemini-2.5-flash', contents: prompt });
            setTranslationResult({ original: textToTranslate, translated: response.text });
        } catch (err) {
            console.error("Gemini API Error:", err);
            setTranslationResult({ original: textToTranslate, translated: "Sorry, translation failed." });
        } finally {
            setIsTranslating(false);
        }
    };

    const handleCopy = () => {
        if (!selectionRange) return;
        navigator.clipboard.writeText(selectionRange.toString());
    };

    const handleShare = () => {
        if (!selectionRange) return;
        navigator.share({ text: selectionRange.toString() }).catch(err => {
            // Do not log an error if the user simply canceled the share action.
            if (err.name !== 'AbortError') {
                console.error("Share failed:", err);
            }
        });
    };

    const updateNoteText = (noteId: string, newText: string) => setNotes(notes.map(n => n.id === noteId ? { ...n, text: newText } : n));
    
    const handleManualAddNote = () => {
        const newNote: Note = { id: `note-${Date.now()}`, quote: '', text: '', highlightId: '' };
        setNotes(prev => [newNote, ...prev]);
        if (!isNotesPanelOpen) setIsNotesPanelOpen(true);
    };

    const handleDeleteNote = (noteToDelete: Note) => {
        setNotes(prev => prev.filter(n => n.id !== noteToDelete.id));
        if (noteToDelete.highlightId) {
            const el = document.getElementById(noteToDelete.highlightId);
            if (el && el.parentNode) {
                const parent = el.parentNode;
                while (el.firstChild) parent.insertBefore(el.firstChild, el);
                parent.removeChild(el);
                parent.normalize();
            }
        }
    };
    
    const fontStyles: React.CSSProperties = { fontSize: `${fontSize}px`, fontFamily: fontFamily === 'serif' ? 'Georgia, "Times New Roman", Times, serif' : '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif', lineHeight: 1.7 };

    const themeClasses = theme === 'light' ? '' : theme;

    const onSelectFile = (file: ProductFile) => {
        setActiveFile(file);
        setIsSidebarOpen(false);
    };

    return (
        <div className={`h-screen w-screen flex flex-col lg:flex-row ebook-reader-root ${themeClasses}`}>
            <style>{`
                .ebook-reader-root { --bg-primary: #ffffff; --bg-secondary: #f7fafc; --text-primary: #1a202c; --text-secondary: #4a5568; --border-color: #e2e8f0; --hover-bg: #edf2f7; --highlight-bg: rgba(251, 235, 95, 0.6); --highlight-note-bg: rgba(167, 219, 255, 0.6); }
                .ebook-reader-root.dark { --bg-primary: #1a202c; --bg-secondary: #2d3748; --text-primary: #edf2f7; --text-secondary: #a0aec0; --border-color: #4a5568; --hover-bg: rgba(255,255,255,0.05); --highlight-bg: rgba(251, 235, 95, 0.4); --highlight-note-bg: rgba(115, 172, 255, 0.4); }
                .ebook-reader-root.sepia { --bg-primary: #fbf5e9; --bg-secondary: #f5efe1; --text-primary: #5c4033; --text-secondary: #7f5539; --border-color: #e3d5b8; --hover-bg: #ede2cc; --highlight-bg: rgba(211, 175, 110, 0.6); --highlight-note-bg: rgba(158, 193, 222, 0.6); }
                .ebook-reader-root.slate { --bg-primary: #1e293b; --bg-secondary: #334155; --text-primary: #e2e8f0; --text-secondary: #94a3b8; --border-color: #475569; --hover-bg: rgba(255,255,255,0.05); --highlight-bg: rgba(251, 235, 95, 0.4); --highlight-note-bg: rgba(115, 172, 255, 0.4); }
                .ebook-reader-root.green { --bg-primary: #f0fdf4; --bg-secondary: #dcfce7; --text-primary: #14532d; --text-secondary: #166534; --border-color: #bbf7d0; --hover-bg: #bbf7d0; --highlight-bg: rgba(251, 235, 95, 0.6); --highlight-note-bg: rgba(167, 219, 255, 0.6); }
                .themed-bg-primary { background-color: var(--bg-primary); } .themed-bg-secondary { background-color: var(--bg-secondary); } .themed-text { color: var(--text-primary); } .themed-text p { color: var(--text-primary); } .themed-text-strong { color: var(--text-primary); } .themed-text-muted { color: var(--text-secondary); } .themed-border { border-color: var(--border-color); } .themed-hover-bg:hover { background-color: var(--hover-bg); } mark.ebook-highlight { background-color: var(--highlight-bg); color: inherit; } mark.ebook-highlight-note { background-color: var(--highlight-note-bg); color: inherit; cursor: pointer; }
                
                /* Enhanced Reader Styles */
                .reader-content img { max-width: 100%; height: auto; display: block; margin: 1rem auto; border-radius: 8px; }
                .reader-content ul, .reader-content ol { margin-left: 1.5rem; margin-bottom: 1rem; }
                .reader-content ul { list-style-type: disc; }
                .reader-content ol { list-style-type: decimal; }
                .reader-content blockquote { border-left: 4px solid var(--border-color); padding-left: 1rem; font-style: italic; color: var(--text-secondary); }
                .reader-content h1, .reader-content h2, .reader-content h3 { font-weight: bold; margin-top: 1.5rem; margin-bottom: 0.5rem; color: var(--text-primary); }
                .reader-content a { color: #3182ce; text-decoration: underline; }
            `}</style>

            {translationResult && (
                 <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" onClick={() => setTranslationResult(null)}>
                    <div className="bg-white rounded-lg shadow-xl w-full max-w-md p-6 animate-pop-in" onClick={e => e.stopPropagation()}>
                        <h3 className="font-bold text-lg mb-4">AI Translation</h3>
                        <div className="space-y-4">
                            <div><p className="text-sm font-semibold text-gray-500 mb-1">Original</p><p className="bg-gray-100 p-2 rounded text-gray-700 max-h-24 overflow-y-auto">{translationResult.original}</p></div>
                            <div><p className="text-sm font-semibold text-blue-600 mb-1">Translation (English)</p><p className="bg-blue-50 p-2 rounded text-blue-800 max-h-24 overflow-y-auto">{translationResult.translated}</p></div>
                        </div>
                        <button onClick={() => setTranslationResult(null)} className="mt-6 w-full bg-primary text-white font-semibold py-2 rounded-lg">Close</button>
                    </div>
                 </div>
            )}
            
            <div onClick={() => setIsSidebarOpen(false)} className={`fixed inset-0 bg-black/60 z-30 lg:hidden transition-opacity ${isSidebarOpen ? "opacity-100" : "opacity-0 pointer-events-none"}`} />
            
            <aside className={`fixed inset-y-0 left-0 z-40 w-80 themed-bg-primary themed-border border-r transform transition-transform lg:relative lg:translate-x-0 lg:flex-shrink-0 ${isSidebarOpen ? "translate-x-0" : "-translate-x-full"}`}>
                <div className="flex flex-col h-full"><div className="p-4 themed-border border-b flex-shrink-0"><button onClick={onBack} className="text-primary font-semibold mb-2 hover:underline">&larr; Back</button><h2 className="text-xl font-bold themed-text-strong" title={product.title}>{product.title}</h2></div><nav className="p-2 overflow-y-auto flex-grow">{product.courseContent?.map(m => <ModuleItem key={m.id} module={m} activeFile={activeFile} onSelectFile={onSelectFile} />) || <p className="p-4 text-center themed-text-muted">No content.</p>}</nav></div>
            </aside>

            <div className="flex-1 flex flex-col min-w-0 relative">
                <header className="sticky top-0 themed-bg-primary shadow-md p-4 flex items-center justify-between flex-shrink-0 z-30 themed-border border-b h-16 relative">
                    {/* Left side */}
                    <div className="flex items-center gap-2 flex-1 min-w-0">
                        <button onClick={() => setIsSidebarOpen(true)} className="p-1 themed-text-muted lg:hidden" aria-label="Open contents">
                            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h7"></path></svg>
                        </button>
                        <h1 className="text-lg font-bold themed-text truncate" title={activeFile?.name}>{activeFile?.name}</h1>
                        {!isInteractive && activeFile && (
                            <span className="text-xs bg-gray-200 text-gray-600 px-2 py-1 rounded-md hidden sm:inline-block">Read-Only View</span>
                        )}
                    </div>

                    {/* Center - ABSOLUTELY POSITIONED Text Action Toolbar */}
                    <div className={`absolute left-1/2 -translate-x-1/2 top-1/2 -translate-y-1/2 transition-opacity duration-300 ${selectionRange && isInteractive ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
                        <div className="flex-none flex items-center gap-1 bg-gray-200 dark:bg-slate-700 text-gray-800 dark:text-white rounded-full shadow-inner p-1">
                            <button title="Highlight" onClick={() => performAction(handleHighlight)} className="px-3 py-1.5 text-sm rounded-full hover:bg-gray-300 dark:hover:bg-slate-600 transition-colors">Highlight</button>
                            <button title="Add Note" onClick={() => performAction(handleAddNote)} className="px-3 py-1.5 text-sm rounded-full hover:bg-gray-300 dark:hover:bg-slate-600 transition-colors">Note</button>
                            <button title="Translate" onClick={() => performAction(handleTranslate)} disabled={isTranslating} className="px-3 py-1.5 text-sm rounded-full hover:bg-gray-300 dark:hover:bg-slate-600 transition-colors disabled:opacity-50 w-20">{isTranslating ? '...' : 'Translate'}</button>
                            <button title="Copy" onClick={() => performAction(handleCopy)} className="px-3 py-1.5 text-sm rounded-full hover:bg-gray-300 dark:hover:bg-slate-600 transition-colors">Copy</button>
                            <button title="Share" onClick={() => performAction(handleShare)} className="px-3 py-1.5 text-sm rounded-full hover:bg-gray-300 dark:hover:bg-slate-600 transition-colors">Share</button>
                        </div>
                    </div>

                    {/* Right side */}
                    <div className="flex items-center gap-2 flex-1 justify-end">
                        {isInteractive && (
                            <>
                                <button onClick={() => setIsNotesPanelOpen(p => !p)} className="p-2 themed-text-muted themed-hover-bg rounded-full" aria-label="Notes"><svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor"><path d="M17.414 2.586a2 2 0 00-2.828 0L7 10.172V13h2.828l7.586-7.586a2 2 0 000-2.828z" /><path fillRule="evenodd" d="M2 6a2 2 0 012-2h4a1 1 0 010 2H4v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" clipRule="evenodd" /></svg></button>
                                <button onClick={() => setIsSettingsPanelOpen(p => !p)} className="p-2 themed-text-muted themed-hover-bg rounded-full" aria-label="Display Settings"><svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor"><path d="M17.132 4.432c-.138-.432-.379-.834-.707-1.162A3.997 3.997 0 0013.293 2H6.707a3.997 3.997 0 00-3.132 1.27c-.328.328-.569.73-.707 1.162A3.993 3.993 0 002 6.707V10h16V6.707a3.993 3.993 0 00-.868-2.275zM2 12v1.293c0 1.253.513 2.427 1.343 3.257.828.828 2.004 1.343 3.257 1.343h6.586c1.253 0 2.429-.515 3.257-1.343.83-.83 1.343-2.004 1.343-3.257V12H2z" /></svg></button>
                            </>
                        )}
                    </div>
                    <div ref={settingsPanelRef}>
                        {isSettingsPanelOpen && <SettingsPanel theme={theme} onThemeChange={setTheme} fontSize={fontSize} onFontSizeChange={setFontSize} fontFamily={fontFamily} onFontFamilyChange={setFontFamily} />}
                    </div>
                </header>
                
                <div className="ebook-content-area flex-1 flex flex-col min-h-0" ref={contentRef}>
                    <main style={{ flexBasis: `${ebookPanelHeight}%` }} className="themed-bg-secondary w-full h-full overflow-y-auto themed-text flex-shrink-0 relative">
                        {isInteractive ? (
                            <div className="max-w-prose mx-auto p-8 md:p-12 lg:p-16 reader-content" style={fontStyles}>
                                <h1 className="text-3xl md:text-4xl font-bold mb-8 themed-text-strong">{activeFile?.name}</h1>
                                <div dangerouslySetInnerHTML={{ __html: activeFile?.content || '<p>No content available.</p>' }} />
                            </div>
                        ) : isPdf && activeFile?.url ? (
                            <div className="w-full h-full flex flex-col items-center justify-center bg-gray-100">
                                <iframe src={activeFile.url} title={activeFile.name} className="w-full h-full border-0" />
                                <div className="absolute top-4 bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 shadow-lg max-w-md mx-auto z-10 opacity-90 hover:opacity-100 transition-opacity">
                                    <p className="font-bold">Note:</p>
                                    <p>This is a PDF file. Highlighting and AI features are disabled. To use these features, please add content using the "Write/Paste Article" option in the admin panel.</p>
                                </div>
                            </div>
                        ) : (
                             <div className="w-full h-full flex items-center justify-center">
                                <div className="text-center p-8 max-w-md">
                                    <p className="text-xl themed-text-strong mb-4">Default Placeholder Content</p>
                                    <p className="themed-text-muted">Please select an "Interactive Text" chapter or a PDF from the sidebar.</p>
                                </div>
                            </div>
                        )}
                    </main>
                    
                    {isInteractive && (
                        <>
                            <div className={`w-full h-2 themed-bg-primary themed-border border-y cursor-ns-resize transition-colors flex-shrink-0 z-10`} />
                            <aside className="flex-1 themed-bg-primary min-h-0"><AiMentor productTitle={product.title} activeContentName={activeFile?.name || null} /></aside>
                        </>
                    )}
                </div>
            </div>

            {isInteractive && (
                <div className={`fixed top-0 right-0 h-full w-full max-w-sm themed-bg-primary shadow-2xl themed-border border-l transform transition-transform duration-300 z-30 ${isNotesPanelOpen ? 'translate-x-0' : 'translate-x-full'}`}>
                    <div className="flex flex-col h-full">
                        <header className="p-4 flex items-center justify-between themed-border border-b flex-shrink-0">
                            <h2 className="font-bold text-xl themed-text-strong">Notes</h2>
                            <button onClick={() => setIsNotesPanelOpen(false)} className="p-1 themed-text-muted themed-hover-bg rounded-full">&times;</button>
                        </header>
                        <div className="flex-1 overflow-y-auto p-4">
                            <button onClick={handleManualAddNote} className="w-full text-center p-2 rounded-lg bg-blue-500 text-white font-semibold hover:bg-blue-600 mb-4 transition-colors">+ Add Custom Note</button>
                            <div className="space-y-4">
                                {notes.length > 0 ? notes.map(note => (
                                    <div key={note.id} className="themed-bg-secondary p-3 rounded-lg relative group">
                                         <button onClick={() => handleDeleteNote(note)} className="absolute top-2 right-2 p-1 rounded-full bg-gray-300 text-gray-700 opacity-0 group-hover:opacity-100 hover:bg-red-500 hover:text-white transition-opacity z-10" aria-label="Delete note"><svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg></button>
                                        {note.quote && <blockquote className="border-l-4 themed-border pl-2 text-sm italic themed-text-muted">"{note.quote}"</blockquote>}
                                        <textarea value={note.text} onChange={e => updateNoteText(note.id, e.target.value)} rows={note.quote ? 3 : 5} placeholder={note.quote ? "Your thoughts..." : "Type your note here..."} className="w-full bg-transparent p-2 mt-2 rounded themed-text focus:outline-none focus:ring-1 focus:ring-primary"></textarea>
                                    </div>
                                )) : <p className="text-center themed-text-muted p-8">Select text to create a note, or add a custom note above.</p>}
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default EbookReader;
