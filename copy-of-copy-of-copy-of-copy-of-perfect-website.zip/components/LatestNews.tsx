import React, { useRef, useEffect } from 'react';
import { NewsArticle, WebsiteSettings } from '../App';

interface LatestNewsProps {
  settings: WebsiteSettings;
  title: string;
  articles: NewsArticle[];
  onReadMoreClick: () => void;
}

const NewsCard: React.FC<{ article: NewsArticle, animationDelay: number, settings: WebsiteSettings, onReadMoreClick: () => void }> = ({ article, animationDelay, settings, onReadMoreClick }) => {
    const animationClass = settings.animations.enabled ? `animate-child animate-delay-${(animationDelay % 8) + 1}` : '';
    return (
        <div className={`bg-white rounded-xl shadow-md overflow-hidden transform hover:-translate-y-2 transition-transform duration-300 group ${animationClass}`}>
            <div className="relative">
                <div className="aspect-video bg-gray-200">
                    <img src={`https://picsum.photos/seed/${article.imageSeed}/800/600`} alt={article.title} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" />
                </div>
            </div>
            <div className="p-6">
                <p className="text-sm font-semibold text-primary tracking-widest uppercase">{article.category}</p>
                <h3 className="mt-2 text-xl font-bold text-gray-800 group-hover:text-primary transition-colors">{article.title}</h3>
                <p className="mt-3 text-sm text-gray-600">{article.excerpt}</p>
                <button onClick={onReadMoreClick} className="mt-4 inline-block font-semibold text-primary group-hover:underline">
                    Read More &rarr;
                </button>
            </div>
        </div>
    );
};

const LatestNews: React.FC<LatestNewsProps> = ({ settings, title, articles, onReadMoreClick }) => {
  const sectionRef = useRef<HTMLElement>(null);
  const gridRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
        (entries) => {
            const [entry] = entries;
            entry.target.classList.toggle('is-visible', entry.isIntersecting);
        }, { threshold: 0.1 }
    );
    const currentRef = sectionRef.current;
    if (currentRef) observer.observe(currentRef);
    
    const gridObserver = new IntersectionObserver(
        (entries) => {
            const [entry] = entries;
            entry.target.classList.toggle('is-visible', entry.isIntersecting);
        }, { threshold: 0.1 }
    );
    const currentGridRef = gridRef.current;
    if(currentGridRef) gridObserver.observe(currentGridRef);

    return () => {
        if (currentRef) observer.unobserve(currentRef);
        if (currentGridRef) gridObserver.unobserve(currentGridRef);
    };
  }, []);

  if (articles.length === 0) return null;

  return (
    <section 
      id="news" 
      ref={sectionRef}
      className={`py-20 sm:py-24 bg-gray-100 ${settings.animations.enabled ? 'scroll-animate' : ''}`}
    >
      <div className="container mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto">
          <h2 className="text-3xl sm:text-4xl font-extrabold text-primary">{title}</h2>
          <p className="mt-4 text-lg text-text-muted">
            Insights and strategies to help you grow your digital business.
          </p>
        </div>
        <div ref={gridRef} className={`mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 ${settings.animations.enabled ? 'stagger-animate-container' : ''}`}>
          {articles.map((article, index) => (
            <NewsCard 
              key={article.id}
              settings={settings}
              article={article} 
              animationDelay={index}
              onReadMoreClick={onReadMoreClick}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default LatestNews;