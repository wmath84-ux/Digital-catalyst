import React, { useState, useEffect, useRef } from 'react';
import { WebsiteSettings } from '../App';

export interface ServiceItem {
    id: number;
    title: string;
    description: string;
}

const ServiceIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
    </svg>
);

interface ServiceCardProps {
    title: string;
    description: string;
    onRequestQuote: () => void;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ title, description, onRequestQuote }) => (
    <div className="relative overflow-hidden bg-white p-8 rounded-xl shadow-lg border border-gray-100 text-center h-full flex flex-col transition-all duration-300 ease-in-out hover:shadow-2xl hover:-translate-y-2 product-card-shine">
        <div className="flex justify-center mb-6">
           <ServiceIcon />
        </div>
        <h3 className="text-xl font-bold text-primary">{title}</h3>
        <p className="mt-3 text-text-muted flex-grow">{description}</p>
        <button onClick={onRequestQuote} className="text-primary font-semibold mt-6 inline-block hover:underline">Request a Quote →</button>
    </div>
);

interface ServicesProps {
    settings: WebsiteSettings;
    services: ServiceItem[];
    onNavigateToHomeAndScroll: (sectionId: string) => void;
}

const Services: React.FC<ServicesProps> = ({ settings, services, onNavigateToHomeAndScroll }) => {
    const sectionRef = useRef<HTMLElement>(null);

    useEffect(() => {
        const observer = new IntersectionObserver(
            (entries) => {
                const [entry] = entries;
                entry.target.classList.toggle('is-visible', entry.isIntersecting);
            },
            { threshold: 0.05 }
        );

        const currentRef = sectionRef.current;
        if (currentRef) {
            observer.observe(currentRef);
        }

        return () => {
            if (currentRef) {
                observer.unobserve(currentRef);
            }
        };
    }, []);

    return (
        <section 
            id="services" 
            ref={sectionRef}
            className={`py-20 sm:py-24 ${settings.animations.enabled ? 'scroll-animate' : ''}`}
        >
            <div className="container mx-auto px-6">
                <div className="text-center max-w-3xl mx-auto">
                    <h2 className="text-3xl sm:text-4xl font-extrabold text-primary">Our Marketing Services</h2>
                    <p className="mt-4 text-lg text-text-muted">
                        Let our experts handle the marketing, so you can focus on your business.
                    </p>
                </div>
                <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8">
                    {services.map((service) => (
                        <ServiceCard key={service.id} {...service} onRequestQuote={() => onNavigateToHomeAndScroll('contact')} />
                    ))}
                </div>
            </div>
        </section>
    );
};

export default Services;