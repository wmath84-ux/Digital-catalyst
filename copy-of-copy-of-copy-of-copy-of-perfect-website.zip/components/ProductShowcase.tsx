import React, { useState, useEffect, useRef } from 'react';
import { ProductWithRating, WebsiteSettings, Coupon } from '../App';
import ProductCard from './ProductCard';

interface ProductShowcaseProps {
  settings: WebsiteSettings;
  products: ProductWithRating[];
  onViewProduct: (product: ProductWithRating, sectionId?: string) => void;
  wishlist: number[];
  onToggleWishlist: (id: number) => void;
  onAddToCart: (productId: number, quantity?: number) => void;
  onQuickView: (product: ProductWithRating) => void;
  coupons: Coupon[];
}

const ProductShowcase: React.FC<ProductShowcaseProps> = ({ settings, products, onViewProduct, wishlist, onToggleWishlist, onAddToCart, onQuickView, coupons }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('default'); // 'default', 'newest', 'rating', 'price-asc', 'price-desc'
  const [activeFilter, setActiveFilter] = useState<string>('All');
  const sectionRef = useRef<HTMLElement>(null);
  const gridRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
        (entries) => {
            const [entry] = entries;
            entry.target.classList.toggle('is-visible', entry.isIntersecting);
        },
        { threshold: 0.05 }
    );

    const currentRef = sectionRef.current;
    if (currentRef) {
        observer.observe(currentRef);
    }
    
    const gridObserver = new IntersectionObserver(
        (entries) => {
            const [entry] = entries;
            entry.target.classList.toggle('is-visible', entry.isIntersecting);
        },
        { threshold: 0.05 }
    );
    const currentGridRef = gridRef.current;
    if(currentGridRef) gridObserver.observe(currentGridRef);


    return () => {
        if (currentRef) observer.unobserve(currentRef);
        if (currentGridRef) gridObserver.unobserve(currentGridRef);
    };
  }, []);
  
  // Get dynamic filters from product tags and categories
  const allTags = products.flatMap(p => p.tags || []);
  const allCategories = products.map(p => p.category).filter((c): c is string => !!c);
  // Using a Set to get unique values from both categories and tags, and then sorting them
  const uniqueKeywords = [...new Set([...allCategories, ...allTags])].sort();
  const filters = ['All', ...uniqueKeywords];


  const getPrice = (product: ProductWithRating) => {
    return product.salePrice ? parseFloat(product.salePrice.replace('₹', '')) : parseFloat(product.price.replace('₹', ''));
  };

  const displayProducts = products
    .filter(product => {
        const query = searchQuery.toLowerCase();
        
        const filterMatch = activeFilter === 'All'
            || product.category === activeFilter
            || (product.tags && product.tags.includes(activeFilter));

        if (!query) return filterMatch;

        const searchMatch = (
            product.title.toLowerCase().includes(query) ||
            product.description.toLowerCase().includes(query) ||
            (product.category && product.category.toLowerCase().includes(query)) ||
            (product.sku && product.sku.toLowerCase().includes(query)) ||
            (product.tags && product.tags.some(tag => tag.toLowerCase().includes(query)))
        );

        return filterMatch && searchMatch;
    })
    .sort((a, b) => {
        switch (sortBy) {
            case 'newest': return b.id - a.id;
            case 'rating': return b.rating - a.rating;
            case 'price-asc': return getPrice(a) - getPrice(b);
            case 'price-desc': return getPrice(b) - getPrice(a);
            default: return 0;
        }
    });

  return (
    <section 
      id="products" 
      ref={sectionRef}
      className={`py-20 sm:py-24 bg-white ${settings.animations.enabled ? 'scroll-animate' : ''}`}
    >
      <div className="container mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto">
          <h2 className="text-3xl sm:text-4xl font-extrabold text-primary">All Products</h2>
          <p className="mt-4 text-lg text-text-muted">
            Browse our full catalog or use the search bar to find exactly what you need.
          </p>
        </div>

        <div className="mt-12 max-w-2xl mx-auto">
          <div className="relative">
            <input 
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by title, category, tags, SKU..."
              className="w-full px-5 py-3 text-lg border-2 border-gray-300 rounded-full focus:ring-2 focus:ring-primary focus:border-transparent transition"
            />
            <svg className="absolute right-5 top-1/2 -translate-y-1/2 w-6 h-6 text-gray-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
          </div>
        </div>
        
        <div className="mt-8 flex flex-wrap justify-center items-center gap-3">
          {filters.map(filter => (
            <button key={filter} onClick={() => setActiveFilter(filter)} className={`px-5 py-2 text-sm font-semibold rounded-full transition-all duration-300 capitalize ${activeFilter === filter ? 'bg-primary text-white shadow' : 'bg-gray-100 text-text-muted hover:bg-gray-200'}`}>
              {filter}
            </button>
          ))}
        </div>

        <div className="mt-8 max-w-xs mx-auto">
            <label htmlFor="sort-by" className="sr-only">Sort products by</label>
            <select
                id="sort-by"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="w-full px-4 py-2 text-base border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent transition bg-white"
            >
                <option value="default">Default Sorting</option>
                <option value="newest">Sort by Newest</option>
                <option value="rating">Sort by Top Rated</option>
                <option value="price-asc">Sort by Price: Low to High</option>
                <option value="price-desc">Sort by Price: High to Low</option>
            </select>
        </div>

        <div ref={gridRef} className={`mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12 ${settings.animations.enabled ? 'stagger-animate-container' : ''}`}>
          {displayProducts.length > 0 ? (
            displayProducts.map((product, index) => (
              <ProductCard 
                key={product.id} 
                settings={settings}
                product={product} 
                onViewDetails={(sectionId) => onViewProduct(product, sectionId)}
                isWishlisted={wishlist.includes(product.id)}
                onToggleWishlist={onToggleWishlist}
                onAddToCart={onAddToCart}
                onQuickView={onQuickView}
                animationDelay={index}
                coupons={coupons}
              />
            ))
          ) : (
            <div className="col-span-full text-center py-12">
              <p className="text-xl text-text-muted">No products found matching your search.</p>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default ProductShowcase;