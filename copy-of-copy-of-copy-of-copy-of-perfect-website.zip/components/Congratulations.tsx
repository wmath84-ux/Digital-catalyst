import React, { useState, useEffect } from 'react';
import Faq from './Faq';
import Services from './Services';
import RatingsAndReviews from './RatingsAndReviews';
import { ProductWithRating, Review, ProductFile, CourseModule, WebsiteSettings } from '../App';

interface CongratulationsProps {
  settings: WebsiteSettings;
  onBack: () => void;
  product: ProductWithRating | null;
  reviews: Review[];
  onAddReview: (reviewData: Omit<Review, 'name' | 'date'>) => void;
}

const dataURLtoBlob = (dataurl: string) => {
    const arr = dataurl.split(',');
    const mimeMatch = arr[0].match(/:(.*?);/);
    if (!mimeMatch) return null;
    const mime = mimeMatch[1];
    const bstr = atob(arr[1]);
    let n = bstr.length;
    const u8arr = new Uint8Array(n);
    while (n--) u8arr[n] = bstr.charCodeAt(n);
    return new Blob([u8arr], { type: mime });
}

const Congratulations: React.FC<CongratulationsProps> = ({ settings, onBack, product, reviews, onAddReview }) => {
  const [showProduct, setShowProduct] = useState(false);
  const [pdfObjectUrl, setPdfObjectUrl] = useState<string | null>(null);
  const [isPdfLoading, setIsPdfLoading] = useState(true);
  
  const getFirstPurchasedFile = (): ProductFile | null => {
    if (!product || !product.courseContent) return null;
    const findFirstFile = (modules: CourseModule[]): ProductFile | null => {
        for (const module of modules) {
            if (module.files.length > 0) return module.files[0];
            const foundInSub = findFirstFile(module.modules);
            if (foundInSub) return foundInSub;
        }
        return null;
    }
    return findFirstFile(product.courseContent);
  }

  const file = getFirstPurchasedFile();

  useEffect(() => {
    if (!file || file.type !== 'pdf') {
        setPdfObjectUrl(null);
        return;
    }
    setIsPdfLoading(true);
    let objectUrl: string | undefined;
    const blob = dataURLtoBlob(file.url);
    if (blob) {
        objectUrl = URL.createObjectURL(blob);
        setPdfObjectUrl(objectUrl);
    } else {
        setPdfObjectUrl(null);
    }
    setIsPdfLoading(false);
    return () => { if (objectUrl) URL.revokeObjectURL(objectUrl); };
  }, [file]);


  const renderProductPreview = () => {
      if (!file) return <p className="text-text-muted">Your product is being processed and will be available in your account shortly.</p>;
      if (file.type === 'video') return <video src={file.url} controls className="w-full h-auto rounded-lg" />;
      if (file.type === 'audio') return <audio src={file.url} controls className="w-full" />;
      if (file.type === 'pdf') {
          if (isPdfLoading) return <div className="p-8 text-center text-text-muted">Loading PDF Preview...</div>;
          if (pdfObjectUrl) {
            return (
              <iframe src={`${pdfObjectUrl}#toolbar=1`} title={file.name} className="w-full h-[80vh] border-0">
                  <div className="p-8 text-center text-text-muted bg-gray-100 h-full flex flex-col justify-center items-center">
                      <h3 className="text-xl font-bold mb-4">PDF Preview Unavailable</h3>
                      <p>Your browser cannot display the PDF file directly.</p>
                      <a href={file.url} download={file.name} className="mt-4 px-6 py-2 rounded-lg bg-primary text-white hover:opacity-90 font-semibold no-underline transform active:scale-95 transition-transform">Download PDF</a>
                  </div>
              </iframe>
            );
          }
          return (
             <div className="p-8 text-center text-text-muted bg-gray-100 h-full flex flex-col justify-center items-center">
                <h3 className="text-xl font-bold mb-4 text-red-600">PDF Preview Error</h3>
                <p>Could not load the PDF file.</p>
                <a href={file.url} download={file.name} className="mt-4 px-6 py-2 rounded-lg bg-primary text-white hover:opacity-90 font-semibold no-underline transform active:scale-95 transition-transform">Download PDF</a>
            </div>
          );
      }
      return <p className="text-text-muted">Preview is not available. Access it from "My Purchases".</p>;
  }

  const animationClass = (delay: string) => settings.animations.enabled ? `animate-fade-in-up style={{ animationDelay: '${delay}' }}` : '';

  return (
    <div className="bg-white min-h-screen">
      <header className="bg-background py-6 border-b">
        <div className="container mx-auto px-6 flex justify-between items-center">
            <h1 className="text-2xl font-bold text-primary">Digital Catalyst</h1>
            <button onClick={onBack} className="bg-primary text-white font-semibold px-6 py-2 rounded-lg hover:opacity-90 transition-all duration-300 transform active:scale-95">
              Back to Home
            </button>
        </div>
      </header>

      <main className="container mx-auto px-6 py-16 text-center">
        <div className="max-w-3xl mx-auto">
          <svg xmlns="http://www.w3.org/2000/svg" className={`h-24 w-24 text-green-500 mx-auto ${settings.animations.enabled ? 'animate-pop-in' : ''}`} viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
          </svg>
          <h2 className={`mt-6 text-4xl sm:text-5xl font-extrabold text-primary tracking-tight ${animationClass('0.2s')}`}>
            Congratulations!
          </h2>
          <p className={`mt-6 text-lg lg:text-xl text-text-muted ${animationClass('0.4s')}`}>
            Your purchase is complete. You can now access your product(s) on the homepage under "My Purchases".
          </p>
        </div>

        <div className={`mt-12 ${animationClass('0.6s')}`}>
          <button onClick={() => setShowProduct(!showProduct)} className="bg-primary text-white font-semibold px-8 py-3 rounded-lg hover:opacity-90 transition-all duration-300 transform hover:scale-105 active:scale-100">
            {showProduct ? 'Hide' : 'Preview'} Your Product
          </button>
        </div>
        
        <div className={`transition-all duration-500 ease-in-out overflow-hidden ${showProduct ? 'max-h-[100vh] opacity-100 mt-12' : 'max-h-0 opacity-0 mt-0'}`}>
            <div className="max-w-5xl mx-auto border-4 border-gray-200 rounded-lg overflow-hidden bg-gray-100 p-4">
                {renderProductPreview()}
            </div>
        </div>
      </main>
      
      {settings.features.showReviews && product && (
        <div className="py-16 bg-background">
            <RatingsAndReviews 
                settings={settings}
                productTitle={product.title} 
                prompt="How was your experience? Your feedback helps us and other customers."
                reviews={reviews}
                onAddReview={onAddReview} 
            />
        </div>
      )}

      <div className="bg-primary text-white py-12" id="contact">
          <div className="container mx-auto px-6 text-center">
              <h3 className="text-3xl font-bold">Need Help or Have Questions?</h3>
              <p className="mt-4 max-w-2xl mx-auto">Our team is here to support you.</p>
              <div className="mt-8 flex flex-col sm:flex-row justify-center items-center gap-6">
                  <a href="mailto:wmath84@gmail.com" className="font-semibold text-lg hover:underline">wmath84@gmail.com</a>
                  <a href="https://wa.me/916307730041" target="_blank" rel="noopener noreferrer" className="bg-white text-primary font-bold px-8 py-3 rounded-lg hover:bg-gray-200 transition-all duration-300 transform active:scale-95">
                      Join on WhatsApp
                  </a>
              </div>
          </div>
      </div>
      
      {/* FIX: Added missing 'services' prop and corrected 'onNavigateToHomeAndScroll' function signature. */}
      <Services settings={settings} services={settings.content.services} onNavigateToHomeAndScroll={(_sectionId) => onBack()} />
      {/* FIX: Added missing 'faqs' prop. */}
      <Faq settings={settings} faqs={settings.content.faqs} />
    </div>
  );
};

export default Congratulations;
