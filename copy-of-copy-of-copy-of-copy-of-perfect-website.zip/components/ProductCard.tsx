import React from 'react';
import { ProductWithRating, WebsiteSettings, Coupon } from '../App';

interface ProductCardProps {
  settings: WebsiteSettings;
  product: ProductWithRating;
  onViewDetails: (sectionId?: string) => void;
  isWishlisted: boolean;
  onToggleWishlist: (id: number) => void;
  onAddToCart: (productId: number, quantity?: number) => void;
  onQuickView: (product: ProductWithRating) => void;
  animationDelay: number;
  displayMode?: 'showcase' | 'wishlist';
  coupons: Coupon[];
}

const ProductCard: React.FC<ProductCardProps> = ({ settings, product, onViewDetails, isWishlisted, onToggleWishlist, onAddToCart, onQuickView, animationDelay, displayMode = 'showcase', coupons }) => {
    const animationClass = settings.animations.enabled ? `animate-child animate-delay-${(animationDelay % 8) + 1}` : '';
    const displayImage = product.images && product.images.length > 0 ? product.images[0] : `https://picsum.photos/seed/${product.imageSeed}/600/400`;
    
    // New logic to check coupon availability
    const associatedCoupon = product.couponCode ? coupons.find(c => c.code === product.couponCode) : null;
    let isCouponAvailable = false;
    if (associatedCoupon) {
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        let expiryDate = new Date();
        try {
            const [year, month, day] = associatedCoupon.expiryDate.split('-').map(Number);
            expiryDate = new Date(year, month - 1, day);
            expiryDate.setHours(23, 59, 59, 999);
        } catch(e) {
            // Invalid date format, coupon is not available
        }
        
        isCouponAvailable = 
            associatedCoupon.isActive &&
            associatedCoupon.timesUsed < associatedCoupon.usageLimit &&
            expiryDate >= today;
    }

    return (
        <div className={`relative bg-white rounded-xl shadow-lg overflow-hidden transform hover:-translate-y-2 hover:scale-[1.03] transition-all duration-300 ease-in-out hover:shadow-2xl border border-gray-100 flex flex-col group product-card-shine ${animationClass}`}>
            <div className="relative w-full overflow-hidden aspect-[4/3]">
                <img src={displayImage} alt={product.title} className="absolute inset-0 w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" />
                
                {displayMode === 'showcase' && (
                    <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/70 via-black/50 to-transparent transform translate-y-full group-hover:translate-y-0 transition-transform duration-300 ease-in-out">
                        <div className="flex items-center justify-center gap-2">
                             <button onClick={() => onAddToCart(product.id, 1)} className="bg-white text-primary font-semibold px-4 py-2 rounded-lg hover:bg-gray-200 transition-all text-sm transform active:scale-95">Add to Cart</button>
                             <button onClick={() => onQuickView(product)} className="bg-white/80 backdrop-blur-sm text-primary font-semibold px-4 py-2 rounded-lg hover:bg-white transition-all text-sm transform active:scale-95">Quick View</button>
                        </div>
                    </div>
                )}

                {product.isFree && (
                     <div className="absolute top-2 left-2 bg-blue-500 text-white px-3 py-1 text-sm font-bold tracking-wide rounded-md shadow-lg">
                        FREE
                    </div>
                )}
                {isCouponAvailable && product.couponCode && !product.isFree && settings.features.showSaleBadges ? (
                    <button 
                        onClick={() => onViewDetails('price-section')} 
                        className="absolute top-4 left-4 bg-indigo-600 text-white px-3 py-1 rounded-full text-xs font-bold tracking-wider hover:scale-110 transition-transform duration-200 z-10 font-mono"
                        title={`Use coupon ${product.couponCode} for a discount!`}
                    >
                        {product.couponCode}
                    </button>
                ) : product.salePrice && !product.isFree && settings.features.showSaleBadges && (
                    <button onClick={() => onViewDetails('price-section')} className="absolute top-4 left-4 bg-red-500 text-white px-3 py-1 rounded-full text-sm font-bold tracking-wide animate-pulse hover:scale-110 transition-transform duration-200 z-10">
                        SALE
                    </button>
                )}
                {settings.features.showFavourites && (
                    <button 
                        onClick={() => onToggleWishlist(product.id)}
                        className="absolute top-4 right-4 bg-white/80 backdrop-blur-sm rounded-full p-2 text-text-muted hover:text-red-500 hover:scale-110 transition-all duration-200 z-10"
                        aria-label={isWishlisted ? 'Remove from Wishlist' : 'Add to Wishlist'}
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill={isWishlisted ? 'currentColor' : 'none'} viewBox="0 0 24 24" stroke="currentColor" strokeWidth={isWishlisted ? 0 : 2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M4.318 6.318a4.5 4.5 0 016.364 0L12 7.636l1.318-1.318a4.5 4.5 0 116.364 6.364L12 20.364l-7.682-7.682a4.5 4.5 0 010-6.364z" />
                        </svg>
                    </button>
                )}
                {settings.features.showReviews && product.rating > 0 && (
                    <button onClick={() => onViewDetails('reviews-section')} className="absolute bottom-4 left-4 bg-yellow-400 text-yellow-900 px-2 py-0.5 rounded-full text-sm font-semibold flex items-center hover:scale-110 hover:bg-yellow-500 transition-all duration-200 z-10 opacity-100 group-hover:opacity-0 group-hover:-translate-y-4">
                        <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" /></svg>
                        {product.rating.toFixed(1)}
                    </button>
                )}
            </div>
            <div className="p-6 flex flex-col flex-grow">
                <h3 className="text-xl font-bold text-primary">{product.title}</h3>
                <p className="mt-2 text-text-muted text-sm flex-grow">{product.description}</p>

                {displayMode === 'showcase' ? (
                     <div className="mt-4 flex justify-between items-center">
                        <div>
                            {product.isFree ? (
                                <div>
                                    <span className="text-sm text-text-muted">Nominal Fee</span>
                                    <p className="text-2xl font-bold text-primary">₹3</p>
                                </div>
                            ) : product.salePrice ? (
                                <div className="flex items-baseline gap-2">
                                    <span className="text-2xl font-bold text-primary">{product.salePrice}</span>
                                    <span className="text-lg font-medium text-gray-400 line-through">{product.price}</span>
                                </div>
                            ) : (
                                <span className="text-2xl font-bold text-primary">{product.price}</span>
                            )}
                        </div>
                        <button onClick={() => onViewDetails()} className="bg-primary text-white font-semibold px-5 py-2 rounded-lg hover:opacity-90 transition-all duration-300 text-sm transform active:scale-95">
                        View Details
                        </button>
                    </div>
                ) : (
                    <div className="mt-4 flex flex-col gap-2">
                        <button 
                            onClick={() => onAddToCart(product.id, 1)} 
                            className="w-full bg-primary text-white font-semibold px-5 py-2.5 rounded-lg hover:opacity-90 transition-all duration-300 transform active:scale-95"
                        >
                            Move to Cart
                        </button>
                        <button 
                            onClick={() => onToggleWishlist(product.id)}
                            className="w-full bg-gray-100 text-gray-600 font-semibold px-5 py-2 rounded-lg hover:bg-gray-200 transition-colors text-sm"
                        >
                            Remove
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
};

export default ProductCard;